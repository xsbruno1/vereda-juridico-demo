"""Expansão isolada de templates e operação Vereda / Relax Studios."""
