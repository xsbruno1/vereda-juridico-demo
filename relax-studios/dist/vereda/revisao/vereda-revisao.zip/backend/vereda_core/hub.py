import base64
import hashlib
import io
import json
import os
import re
import secrets
import sqlite3
import threading
import urllib.request
import zipfile
from datetime import datetime, timezone
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from .compliance import inspect, public_context


class Store:
    """SQLite local: registros criptografados e autenticados, ligados ao tenant.

    Chave por ambiente, nunca serializada com a base. Sem chave configurada,
    usa memória efêmera para a demonstração e não aceita dados de saúde.
    """
    def __init__(self, path=':memory:', key=None):
        self.key = key or AESGCM.generate_key(bit_length=256)
        self.lock = threading.RLock()
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.db.execute('create table if not exists records (tenant text, bucket text, id text, encrypted blob, primary key(tenant,bucket,id))')

    def put(self, tenant, bucket, identifier, value):
        nonce = secrets.token_bytes(12)
        aad = f'{tenant}:{bucket}:{identifier}'.encode()
        body = nonce + AESGCM(self.key).encrypt(nonce, json.dumps(value, ensure_ascii=False).encode(), aad)
        with self.lock, self.db:
            self.db.execute('insert or replace into records values (?,?,?,?)', (tenant, bucket, identifier, body))

    def all(self, tenant, bucket):
        with self.lock:
            rows = self.db.execute('select id,encrypted from records where tenant=? and bucket=?', (tenant,bucket)).fetchall()
        return [json.loads(AESGCM(self.key).decrypt(body[:12], body[12:], f'{tenant}:{bucket}:{identifier}'.encode())) for identifier,body in rows]

    def get(self, tenant, bucket, identifier):
        return next((item for item in self.all(tenant,bucket) if item['id'] == identifier), None)


class OfflineProvider:
    name = 'editorial-offline'
    def generate(self, context, kind):
        brand = context['brand']
        if kind == 'image':
            # Plano de imagem exportável, não uma foto supostamente gerada por IA.
            return {'text': f"Direção visual: ambiente sem pessoas. Cores {', '.join(brand['colors'])}. {context['brief']}",
                    'asset': None, 'image_pending': True}
        match=re.search(r'Ângulo editorial (\d+)',context['brief'])
        index=int(match.group(1))-1 if match else 0
        services=brand.get('services') or ['Atendimento']
        service=services[index%len(services)]
        cta=context['brief'].split('Chamada para ação:')[-1].strip() if 'Chamada para ação:' in context['brief'] else 'Fale com a equipe para informações.'
        detail='Conheça as modalidades e como funciona o primeiro contato, com respeito ao seu tempo.' if brand['sector'] in ('psicologia','psiquiatria') else 'Conheça os detalhes do espaço e consulte as condições para planejar sua visita.'
        hashtags='#'+re.sub(r'[^\w]','',brand['name'])+' #Informação #Atendimento'
        return {'text':hashtags if kind=='hashtags' else f"{brand['name']}\n{service}\n\n{detail}\n\n{cta}\n\n{hashtags}", 'asset':None}


class OpenAIProvider:
    name = 'openai'
    def generate(self, context, kind):
        key = os.environ.get('OPENAI_API_KEY')
        model = os.environ.get('VEREDA_IMAGE_MODEL' if kind == 'image' else 'VEREDA_TEXT_MODEL')
        if not key or not model:
            raise ValueError('Provedor requer chave e modelo configurados no servidor')
        prompt = 'Crie conteúdo institucional usando só este contexto público. Não inclua pacientes, rostos, nudez, promessas ou depoimentos. Respeite todas as restrições. ' + json.dumps(context, ensure_ascii=False)
        path = 'images/generations' if kind == 'image' else 'responses'
        payload = {'model': model, 'prompt': prompt, 'n': 1, 'output_format':'png'} if kind == 'image' else {'model':model, 'input':prompt, 'store':False}
        req = urllib.request.Request('https://api.openai.com/v1/' + path, data=json.dumps(payload).encode(),
                                     headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'})
        with urllib.request.urlopen(req, timeout=90) as response:
            result = json.load(response)
        if kind == 'image':
            asset = result['data'][0].get('b64_json')
            if not asset:
                raise ValueError('Provedor não retornou imagem em base64')
            return {'text': context['brief'], 'asset': asset, 'image_pending': False}
        text = '\n'.join(c['text'] for out in result.get('output',[]) for c in out.get('content',[]) if c.get('type') == 'output_text')
        if not text.strip():
            raise ValueError('Provedor não retornou texto')
        return {'text':text,'asset':None}


class Hub:
    def __init__(self, store=None, provider=None):
        self.store = store or Store()
        self.provider = provider or OfflineProvider()
        self.lock = threading.RLock()

    def log(self, tenant, action, item_id, actor):
        identifier = secrets.token_hex(12)
        self.store.put(tenant, 'audit', identifier, {'id':identifier,'action':action,'item_id':item_id,
                       'actor':actor,'at':datetime.now(timezone.utc).isoformat()})

    def generate(self, tenant, brand, brief, kind='text', scheduled_at=None, channel='instagram', demo=True, delivery_mode='assisted'):
        from .publication import NETWORKS, destination
        if channel not in NETWORKS:
            raise ValueError('Escolha uma rede de destino')
        if delivery_mode not in ('automatic','assisted'):
            raise ValueError('Escolha publicação assistida ou automática')
        if scheduled_at:
            from .editorial import instant
            instant(scheduled_at)
        if kind not in ('text','image','hashtags'):
            raise ValueError('Tipo inválido')
        if brand['sector'] in ('psicologia','psiquiatria') and not brand.get('registration'):
            raise ValueError('Registro profissional obrigatório')
        context = public_context(brand, brief)
        output = self.provider.generate(context, kind)
        if brand['sector'] in ('psicologia','psiquiatria') and brand['registration'] not in output['text']:
            output['text'] += '\n\n' + brand['registration']
        verdict = inspect(output['text'], brand['sector'])
        identifier = secrets.token_hex(12)
        item = {'id':identifier,'brand':brand,'text':output['text'],'asset':output.get('asset'),
                'kind':kind,'provider':self.provider.name,'scheduled_at':scheduled_at,
                'status':'pending' if verdict['allowed'] else 'blocked','reasons':verdict['reasons'],
                'revision':1,'image_pending':output.get('image_pending',False),
                'channel':channel,'demo':demo,'destination':destination(channel),'delivery_mode':delivery_mode}
        self.store.put(tenant,'marketing',identifier,item)
        self.log(tenant,'generated',identifier,'operator')
        return item

    def approve(self, tenant, identifier, reviewer, checks):
        with self.lock:
            item = self.store.get(tenant,'marketing',identifier)
            if not item:
                raise ValueError('Item não encontrado')
            if not reviewer.strip() or not checks.get('human_confirmed'):
                raise ValueError('Revisão humana identificada obrigatória')
            if item.get('image_pending'):
                raise ValueError('Plano visual ainda não contém imagem final')
            if item['kind']=='image' and (not item.get('asset') or not all(k in checks for k in ('reviewed','contains_client_faces','adult_content'))):
                raise ValueError('Imagem final exige inspeção visual e declarações explícitas')
            verdict = inspect(item['text'],item['brand']['sector'],image_review=checks if item['kind']=='image' else None)
            if not verdict['allowed']:
                raise ValueError('Conteúdo bloqueado: ' + ', '.join(verdict['reasons']))
            item.update(status='approved',reviewer=reviewer,approved_hash=self.fingerprint(item))
            self.store.put(tenant,'marketing',identifier,item)
            self.log(tenant,'approved',identifier,reviewer)
            return item

    @staticmethod
    def fingerprint(item):
        return hashlib.sha256(json.dumps({k:item.get(k) for k in ('text','asset','brand','revision','scheduled_at','channel','destination','delivery_mode')},sort_keys=True).encode()).hexdigest()

    def edit(self, tenant, identifier, text):
        with self.lock:
            item = self.store.get(tenant,'marketing',identifier)
            if not item:
                raise ValueError('Item não encontrado')
            item.update(text=text,status='pending',revision=item['revision']+1)
            item.pop('approved_hash',None)
            self.store.put(tenant,'marketing',identifier,item)
            self.log(tenant,'edited',identifier,'operator')
            return item

    def export(self, tenant, identifier):
        item = self.store.get(tenant,'marketing',identifier)
        if not item or item['status'] != 'approved' or item.get('approved_hash') != self.fingerprint(item):
            raise ValueError('Exportação/publicação exige aprovação da versão atual')
        if not inspect(item['text'],item['brand']['sector'])['allowed']:
            raise ValueError('Revalidação bloqueou o conteúdo')
        output = io.BytesIO()
        with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as package:
            package.writestr('legenda.txt',item['text'])
            package.writestr('aprovacao.json',json.dumps({k:v for k,v in item.items() if k!='asset'},ensure_ascii=False,indent=2))
            package.writestr('PUBLICAR.txt','Pacote aprovado para revisão final no canal oficial. Não envia automaticamente. Políticas da plataforma também se aplicam.')
            if item.get('asset'):
                package.writestr('imagem.png',base64.b64decode(item['asset'],validate=True))
        self.log(tenant,'exported',identifier,item['reviewer'])
        return output.getvalue()
