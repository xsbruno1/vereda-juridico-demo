"""Local consultation-domain reference; no network, login, uploads or video provider.

Only trusted server code supplies Portal, encryption keys and the video adapter.
Messages and document references are scoped to a room, its subject and live members.
"""
from __future__ import annotations

from dataclasses import dataclass
from html import escape
import json
import math
import re
import secrets
from typing import Callable, Protocol
from uuid import uuid4

from .core import AccessDenied, Portal


class VideoDisabled(RuntimeError):
    pass


class RateLimited(RuntimeError):
    pass


class VideoRevocationPending(RuntimeError):
    """Local access is blocked; persistent remote cleanup still requires retry."""


@dataclass(frozen=True)
class VideoBinding:
    provider: str
    external_room_id: str


@dataclass(frozen=True)
class JoinRequest:
    external_room_id: str
    participant_id: str
    role: str
    expires_at: float


@dataclass(frozen=True)
class JoinGrant:
    token: str
    external_room_id: str
    participant_id: str
    expires_at: float


class VideoProvider(Protocol):
    name: str

    def issue(self, request: JoinRequest) -> JoinGrant:
        """Use the official provider contract, bound room/identity and <=120s expiry.

        The adapter must authenticate the provider and validate all returned claims.
        This interface does not implement JWT, Google Meet, video or a provider SDK.
        """

    def revoke(self, grant: JoinGrant) -> None:
        """Invalidate a newly issued grant if live authorization changed during issue."""

    def eject(self, external_room_id: str, participant_id: str) -> None:
        """Idempotently remove/block this participant, including an established call."""

    def close_room(self, external_room_id: str) -> None:
        """Idempotently end the external room and prevent further joins."""


def render_message_text(text: str) -> str:
    """For server-rendered HTML only. Browser clients must use textContent, not HTML."""
    return escape(text, quote=True)


class Consultations:
    MAX_TEXT = 2000
    RATE_COUNT = 30
    RATE_SECONDS = 60

    def __init__(self, portal: Portal, *, provider: VideoProvider | None = None,
                 binding_resolver: Callable[[str, str], VideoBinding | None] | None = None):
        self.portal, self.store, self.now = portal, portal.store, portal.now
        self.provider, self.binding_resolver = provider, binding_resolver
        with self.store.lock:
            self.store.db.executescript('''
              CREATE TABLE IF NOT EXISTS consultation_rooms (
                tenant TEXT NOT NULL, id TEXT NOT NULL, subject_id TEXT NOT NULL,
                category TEXT NOT NULL CHECK(category IN('clinical','legal')),
                host_user TEXT NOT NULL, created_at REAL NOT NULL, expires_at REAL NOT NULL,
                closed_at REAL, CHECK(expires_at > created_at), PRIMARY KEY(tenant,id),
                FOREIGN KEY(tenant,subject_id) REFERENCES portal_subjects(tenant,id));
              CREATE TABLE IF NOT EXISTS consultation_members (
                tenant TEXT NOT NULL, room_id TEXT NOT NULL, user_id TEXT NOT NULL,
                id TEXT NOT NULL UNIQUE, kind TEXT NOT NULL CHECK(kind IN('subject','professional')),
                expires_at REAL NOT NULL, revoked INTEGER NOT NULL DEFAULT 0 CHECK(revoked IN(0,1)),
                PRIMARY KEY(tenant,room_id,user_id),
                FOREIGN KEY(tenant,room_id) REFERENCES consultation_rooms(tenant,id));
              CREATE TABLE IF NOT EXISTS consultation_messages (
                tenant TEXT NOT NULL, room_id TEXT NOT NULL, id TEXT NOT NULL,
                sender_user TEXT NOT NULL, request_key TEXT NOT NULL, created_at REAL NOT NULL,
                key_version INTEGER NOT NULL CHECK(key_version > 0), ciphertext BLOB NOT NULL,
                PRIMARY KEY(tenant,room_id,id), UNIQUE(tenant,room_id,sender_user,request_key),
                FOREIGN KEY(tenant,room_id,sender_user)
                  REFERENCES consultation_members(tenant,room_id,user_id));
              CREATE TABLE IF NOT EXISTS consultation_outbox (
                id TEXT PRIMARY KEY, tenant TEXT NOT NULL, room_id TEXT NOT NULL,
                message_id TEXT NOT NULL, created_at REAL NOT NULL,
                UNIQUE(tenant,room_id,message_id),
                FOREIGN KEY(tenant,room_id,message_id)
                  REFERENCES consultation_messages(tenant,room_id,id));
              CREATE TABLE IF NOT EXISTS consultation_documents (
                tenant TEXT NOT NULL, room_id TEXT NOT NULL, id TEXT NOT NULL,
                record_id TEXT NOT NULL, added_by TEXT NOT NULL, created_at REAL NOT NULL,
                revoked INTEGER NOT NULL DEFAULT 0 CHECK(revoked IN(0,1)),
                PRIMARY KEY(tenant,room_id,id), UNIQUE(tenant,room_id,record_id),
                FOREIGN KEY(tenant,room_id) REFERENCES consultation_rooms(tenant,id),
                FOREIGN KEY(tenant,record_id) REFERENCES portal_records(tenant,id));
              CREATE INDEX IF NOT EXISTS consultation_message_rate
                ON consultation_messages(tenant,room_id,sender_user,created_at);
              CREATE TABLE IF NOT EXISTS consultation_video_grants (
                id TEXT PRIMARY KEY, tenant TEXT NOT NULL, room_id TEXT NOT NULL,
                member_id TEXT NOT NULL, provider TEXT NOT NULL, key_version INTEGER NOT NULL,
                ciphertext BLOB NOT NULL, revoked INTEGER NOT NULL DEFAULT 0 CHECK(revoked IN(0,1)),
                FOREIGN KEY(tenant,room_id) REFERENCES consultation_rooms(tenant,id),
                FOREIGN KEY(member_id) REFERENCES consultation_members(id));
              CREATE TABLE IF NOT EXISTS consultation_video_cleanup (
                id TEXT PRIMARY KEY, tenant TEXT NOT NULL, room_id TEXT NOT NULL,
                member_id TEXT, created_at REAL NOT NULL,
                state TEXT NOT NULL CHECK(state IN('pending','done')),
                FOREIGN KEY(tenant,room_id) REFERENCES consultation_rooms(tenant,id),
                FOREIGN KEY(member_id) REFERENCES consultation_members(id));
            ''')

    @staticmethod
    def _id(value):
        if not isinstance(value, str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,128}', value):
            raise ValueError('Identificador inválido.')
        return value

    def _run(self, token, tenant, action, target, operation):
        self._id(tenant)
        self._id(target)
        denied = None
        with self.store.lock, self.store.db:
            identity = self.portal.identify(token)
            try:
                result = operation(identity)
            except AccessDenied:
                denied = AccessDenied('Acesso não autorizado.')
            # Audit contains identifiers only; no message, document, token or diagnosis.
            self.portal._audit(identity, tenant, action, target, denied is None)
        if denied:
            raise denied
        return result

    def _room_member(self, identity, tenant, room_id):
        room = self.store.db.execute('SELECT * FROM consultation_rooms WHERE tenant=? AND id=?',
                                     (tenant, room_id)).fetchone()
        member = self.store.db.execute('''SELECT * FROM consultation_members
            WHERE tenant=? AND room_id=? AND user_id=? AND revoked=0''',
            (tenant, room_id, identity.user_id)).fetchone()
        if (not room or room['closed_at'] is not None or room['expires_at'] <= self.now()
                or not member or member['expires_at'] <= self.now()):
            raise AccessDenied()
        permitted = (self.portal._owner(identity, tenant, room['subject_id'])
                     if member['kind'] == 'subject' else
                     self.portal._staff(identity, tenant, room['subject_id'], room['category']))
        if not permitted:
            raise AccessDenied()
        return room, member

    def _host(self, identity, tenant, room_id):
        room, member = self._room_member(identity, tenant, room_id)
        if member['kind'] != 'professional' or room['host_user'] != identity.user_id:
            raise AccessDenied()
        return room

    def create(self, token, tenant, subject_id, category, *, lifetime=7200):
        if category not in ('clinical', 'legal'):
            raise ValueError('Categoria de atendimento inválida.')
        if type(lifetime) is not int or not 60 <= lifetime <= 28800:
            raise ValueError('A sala deve durar entre um minuto e oito horas.')

        def operation(identity):
            if not self.portal._staff(identity, tenant, subject_id, category):
                raise AccessDenied()
            subject = self.portal._subject(tenant, subject_id)
            if subject['user_id'] == identity.user_id:
                raise AccessDenied()
            room_id, now = str(uuid4()), self.now()
            expires = now + lifetime
            self.store.db.execute('INSERT INTO consultation_rooms VALUES(?,?,?,?,?,?,?,NULL)',
                                  (tenant, room_id, subject_id, category, identity.user_id, now, expires))
            # Explicit provision of exactly the assigned host and the subject; no staff wildcard.
            self.store.db.executemany('INSERT INTO consultation_members VALUES(?,?,?,?,?,?,0)',
                [(tenant, room_id, identity.user_id, str(uuid4()), 'professional', expires),
                 (tenant, room_id, subject['user_id'], str(uuid4()), 'subject', expires)])
            return room_id
        return self._run(token, tenant, 'consultation_create', subject_id, operation)

    def add_professional(self, token, tenant, room_id, user_id):
        self._id(user_id)

        def operation(identity):
            room = self._host(identity, tenant, room_id)
            # Reuse category and assignment checks, not a role supplied by the caller.
            role = self.store.db.execute('''SELECT role FROM portal_memberships
                WHERE tenant=? AND user_id=? AND active=1''', (tenant, user_id)).fetchone()
            assigned = self.store.db.execute('''SELECT 1 FROM portal_assignments
                WHERE tenant=? AND subject_id=? AND user_id=?''',
                (tenant, room['subject_id'], user_id)).fetchone()
            expected = 'clinician' if room['category'] == 'clinical' else 'lawyer'
            if not role or role['role'] != expected or not assigned:
                raise AccessDenied()
            existing = self.store.db.execute('''SELECT revoked FROM consultation_members
                WHERE tenant=? AND room_id=? AND user_id=?''', (tenant, room_id, user_id)).fetchone()
            if existing:
                if existing['revoked']:
                    raise AccessDenied()
                return
            self.store.db.execute('INSERT INTO consultation_members VALUES(?,?,?,?,?,?,0)',
                (tenant, room_id, user_id, str(uuid4()), 'professional', room['expires_at']))
        return self._run(token, tenant, 'consultation_member_add', room_id, operation)

    def revoke_participant(self, token, tenant, room_id, user_id):
        self._id(user_id)

        def operation(identity):
            room = self._host(identity, tenant, room_id)
            if user_id == room['host_user']:
                raise ValueError('Encerre a sala para retirar o responsável.')
            self.store.db.execute('''UPDATE consultation_members SET revoked=1
                WHERE tenant=? AND room_id=? AND user_id=?''', (tenant, room_id, user_id))
            member = self.store.db.execute('''SELECT id FROM consultation_members
                WHERE tenant=? AND room_id=? AND user_id=?''', (tenant, room_id, user_id)).fetchone()
            return self._queue_video_cleanup(tenant, room_id, member['id']) if member else None
        cleanup = self._run(token, tenant, 'consultation_member_revoke', room_id, operation)
        if cleanup:
            self._attempt_video_cleanup(cleanup)

    @staticmethod
    def _aad(row):
        return json.dumps(['consultation-message-v1'] + [row[k] for k in
            ('tenant', 'room_id', 'id', 'sender_user', 'request_key', 'created_at', 'key_version')],
            separators=(',', ':'), allow_nan=False).encode()

    def _message(self, row):
        cipher = row['ciphertext']
        text = self.store.cipher(row['tenant'], row['key_version']).decrypt(
            cipher[:12], cipher[12:], self._aad(row)).decode('utf-8')
        return {'id': row['id'], 'sender_id': row['sender_user'],
                'created_at': row['created_at'], 'text': text}

    def send(self, token, tenant, room_id, text, request_key, *, key_version=1):
        self._id(request_key)
        if (not isinstance(text, str) or not text.strip() or len(text) > self.MAX_TEXT
                or len(text.encode('utf-8')) > 8000
                or any(ord(c) < 32 and c not in '\n\t' for c in text)):
            raise ValueError('Mensagem inválida ou maior que 2.000 caracteres.')

        def operation(identity):
            self._room_member(identity, tenant, room_id)
            old = self.store.db.execute('''SELECT * FROM consultation_messages
                WHERE tenant=? AND room_id=? AND sender_user=? AND request_key=?''',
                (tenant, room_id, identity.user_id, request_key)).fetchone()
            if old:
                result = self._message(old)
                if result['text'] != text:
                    raise ValueError('A chave já foi usada para outra mensagem.')
                return result
            count = self.store.db.execute('''SELECT count(*) FROM consultation_messages
                WHERE tenant=? AND room_id=? AND sender_user=? AND created_at>?''',
                (tenant, room_id, identity.user_id, self.now() - self.RATE_SECONDS)).fetchone()[0]
            if count >= self.RATE_COUNT:
                raise RateLimited('Aguarde antes de enviar mais mensagens.')
            row = dict(tenant=tenant, room_id=room_id, id=str(uuid4()), sender_user=identity.user_id,
                       request_key=request_key, created_at=float(self.now()), key_version=key_version)
            nonce = secrets.token_bytes(12)
            ciphertext = nonce + self.store.cipher(tenant, key_version).encrypt(
                nonce, text.encode('utf-8'), self._aad(row))
            self.store.db.execute('INSERT INTO consultation_messages VALUES(?,?,?,?,?,?,?,?)',
                                  tuple(row.values()) + (ciphertext,))
            self.store.db.execute('INSERT INTO consultation_outbox VALUES(?,?,?,?,?)',
                (str(uuid4()), tenant, room_id, row['id'], row['created_at']))
            return {'id': row['id'], 'sender_id': identity.user_id,
                    'created_at': row['created_at'], 'text': text}
        return self._run(token, tenant, 'consultation_send', room_id, operation)

    def messages(self, token, tenant, room_id, *, after_id=None, limit=50):
        if type(limit) is not int or not 1 <= limit <= 100:
            raise ValueError('Limite inválido.')
        if after_id is not None:
            self._id(after_id)

        def operation(identity):
            self._room_member(identity, tenant, room_id)
            after = 0
            if after_id:
                row = self.store.db.execute('''SELECT rowid FROM consultation_messages
                    WHERE tenant=? AND room_id=? AND id=?''', (tenant, room_id, after_id)).fetchone()
                if not row:
                    raise AccessDenied()
                after = row[0]
            rows = self.store.db.execute('''SELECT * FROM consultation_messages
                WHERE tenant=? AND room_id=? AND rowid>? ORDER BY rowid LIMIT ?''',
                (tenant, room_id, after, limit)).fetchall()
            return [self._message(row) for row in rows]
        return self._run(token, tenant, 'consultation_read', room_id, operation)

    def _released_record(self, identity, room, record_id):
        record = self.portal._record(room['tenant'], record_id)
        if (not record or not record['released'] or record['subject_id'] != room['subject_id']
                or record['category'] != room['category']):
            raise AccessDenied()
        if not (self.portal._owner(identity, room['tenant'], record['subject_id'])
                or self.portal._staff(identity, room['tenant'], record['subject_id'], record['category'])):
            raise AccessDenied()
        return record

    def attach_record(self, token, tenant, room_id, record_id):
        self._id(record_id)

        def operation(identity):
            room, _ = self._room_member(identity, tenant, room_id)
            self._released_record(identity, room, record_id)
            old = self.store.db.execute('''SELECT id,revoked FROM consultation_documents
                WHERE tenant=? AND room_id=? AND record_id=?''', (tenant, room_id, record_id)).fetchone()
            if old:
                if old['revoked']:
                    raise AccessDenied()
                return old['id']
            document_id = str(uuid4())
            self.store.db.execute('INSERT INTO consultation_documents VALUES(?,?,?,?,?,?,0)',
                (tenant, room_id, document_id, record_id, identity.user_id, self.now()))
            return document_id
        return self._run(token, tenant, 'consultation_document_attach', room_id, operation)

    def open_document(self, token, tenant, room_id, document_id):
        self._id(document_id)

        def operation(identity):
            room, _ = self._room_member(identity, tenant, room_id)
            reference = self.store.db.execute('''SELECT * FROM consultation_documents
                WHERE tenant=? AND room_id=? AND id=? AND revoked=0''',
                (tenant, room_id, document_id)).fetchone()
            if not reference:
                raise AccessDenied()
            record = self._released_record(identity, room, reference['record_id'])
            return self.portal._decrypt(record)
        return self._run(token, tenant, 'consultation_document_open', room_id, operation)

    def revoke_document(self, token, tenant, room_id, document_id):
        self._id(document_id)

        def operation(identity):
            room, _ = self._room_member(identity, tenant, room_id)
            reference = self.store.db.execute('''SELECT * FROM consultation_documents
                WHERE tenant=? AND room_id=? AND id=?''', (tenant, room_id, document_id)).fetchone()
            if not reference or identity.user_id not in (room['host_user'], reference['added_by']):
                raise AccessDenied()
            self.store.db.execute('''UPDATE consultation_documents SET revoked=1
                WHERE tenant=? AND room_id=? AND id=?''', (tenant, room_id, document_id))
        return self._run(token, tenant, 'consultation_document_revoke', room_id, operation)

    def close(self, token, tenant, room_id):
        def operation(identity):
            self._host(identity, tenant, room_id)
            self.store.db.execute('UPDATE consultation_rooms SET closed_at=? WHERE tenant=? AND id=?',
                                  (self.now(), tenant, room_id))
            return self._queue_video_cleanup(tenant, room_id, None)
        cleanup = self._run(token, tenant, 'consultation_close', room_id, operation)
        if cleanup:
            self._attempt_video_cleanup(cleanup)

    @staticmethod
    def _grant_aad(row):
        return json.dumps(['consultation-video-v1'] + [row[k] for k in
            ('id', 'tenant', 'room_id', 'member_id', 'provider', 'key_version')],
            separators=(',', ':')).encode()

    def _remember_grant(self, tenant, room_id, member_id, grant):
        row = dict(id=str(uuid4()), tenant=tenant, room_id=room_id, member_id=member_id,
                   provider=self.provider.name, key_version=1)
        raw = json.dumps(grant.__dict__, separators=(',', ':'), allow_nan=False).encode()
        nonce = secrets.token_bytes(12)
        ciphertext = nonce + self.store.cipher(tenant, 1).encrypt(nonce, raw, self._grant_aad(row))
        self.store.db.execute('INSERT INTO consultation_video_grants VALUES(?,?,?,?,?,?,?,0)',
                              tuple(row.values()) + (ciphertext,))

    def _queue_video_cleanup(self, tenant, room_id, member_id):
        exists = self.store.db.execute('''SELECT 1 FROM consultation_video_grants
            WHERE tenant=? AND room_id=? AND (? IS NULL OR member_id=?) LIMIT 1''',
            (tenant, room_id, member_id, member_id)).fetchone()
        if not exists:
            return None
        job_id = str(uuid4())
        self.store.db.execute('INSERT INTO consultation_video_cleanup VALUES(?,?,?,?,?,?)',
            (job_id, tenant, room_id, member_id, self.now(), 'pending'))
        return job_id

    def _attempt_video_cleanup(self, job_id):
        """Trusted worker hook; not an HTTP endpoint. Local revocation is already committed.

        Retry pending jobs after adapter outages. All adapter operations must be idempotent.
        Retain grants past join-token expiry: an established call may still be running.
        """
        with self.store.lock:
            job = self.store.db.execute('SELECT * FROM consultation_video_cleanup WHERE id=?',
                                        (job_id,)).fetchone()
            if not job or job['state'] == 'done':
                return
            rows = self.store.db.execute('''SELECT * FROM consultation_video_grants
                WHERE tenant=? AND room_id=? AND (? IS NULL OR member_id=?)''',
                (job['tenant'], job['room_id'], job['member_id'], job['member_id'])).fetchall()
            try:
                rooms, participants = set(), set()
                for row in rows:
                    if self.provider is None or self.provider.name != row['provider']:
                        raise VideoDisabled()
                    cipher = row['ciphertext']
                    raw = self.store.cipher(row['tenant'], row['key_version']).decrypt(
                        cipher[:12], cipher[12:], self._grant_aad(row))
                    grant = JoinGrant(**json.loads(raw))
                    self.provider.revoke(grant)
                    rooms.add(grant.external_room_id)
                    participants.add((grant.external_room_id, grant.participant_id))
                if job['member_id'] is None:
                    for external_room in rooms:
                        self.provider.close_room(external_room)
                else:
                    for external_room, participant in participants:
                        self.provider.eject(external_room, participant)
                with self.store.db:
                    self.store.db.executemany('UPDATE consultation_video_grants SET revoked=1 WHERE id=?',
                                              [(row['id'],) for row in rows])
                    self.store.db.execute("UPDATE consultation_video_cleanup SET state='done' WHERE id=?", (job_id,))
            except Exception:
                # Do not log provider exceptions: they may contain credentials or URLs.
                # The job stays pending; local participant/room access remains revoked.
                raise VideoRevocationPending('Acesso local bloqueado; encerramento externo pendente.') from None

    def join_video(self, token, tenant, room_id):
        def operation(identity):
            room, member = self._room_member(identity, tenant, room_id)
            if (self.provider is None or self.binding_resolver is None
                    or not all(callable(getattr(self.provider, method, None))
                               for method in ('issue', 'revoke', 'eject', 'close_room'))):
                raise VideoDisabled('Vídeo ainda não conectado.')
            binding = self.binding_resolver(tenant, room_id)
            if (not isinstance(binding, VideoBinding) or binding.provider != self.provider.name
                    or not isinstance(binding.external_room_id, str)
                    or not 1 <= len(binding.external_room_id) <= 256):
                raise VideoDisabled('Sala sem configuração válida de vídeo.')
            request = JoinRequest(binding.external_room_id, member['id'],
                                  'host' if room['host_user'] == identity.user_id else 'participant',
                                  min(self.now() + 120, room['expires_at'], member['expires_at'], identity.expires_at))
            grant = self.provider.issue(request)
            try:
                current = self.portal.identify(token)
                if current.user_id != identity.user_id or current.session_id != identity.session_id:
                    raise AccessDenied()
                current_room, current_member = self._room_member(current, tenant, room_id)
                if (not isinstance(grant, JoinGrant) or not isinstance(grant.token, str)
                        or not 16 <= len(grant.token) <= 8192
                        or grant.external_room_id != request.external_room_id
                        or grant.participant_id != request.participant_id
                        or type(grant.expires_at) not in (int, float) or not math.isfinite(grant.expires_at)
                        or not self.now() < grant.expires_at <= min(request.expires_at, current.expires_at,
                                                                 current_room['expires_at'], current_member['expires_at'])):
                    raise ValueError('Resposta inválida do provedor de vídeo.')
                self._remember_grant(tenant, room_id, member['id'], grant)
            except Exception:
                # The adapter owns provider revocation. Never return a rejected grant.
                try:
                    self.provider.revoke(grant)
                except Exception:
                    pass
                raise
            return grant
        return self._run(token, tenant, 'consultation_video_join', room_id, operation)
