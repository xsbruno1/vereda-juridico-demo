"""Gateway-neutral payment boundary. No network provider is enabled by default.

Actual adapters must implement the gateway's official checkout/signature/reconciliation
contract. The HMAC verifier below is a reference contract, NOT Stripe/Mercado Pago/Asaas.
"""
from dataclasses import dataclass
import hashlib
import hmac
import json
import re
from typing import Protocol
from urllib.parse import urlsplit
from uuid import uuid4

from .core import AccessDenied, Portal


class GatewayDisabled(RuntimeError):
    pass


@dataclass(frozen=True)
class Checkout:
    external_id: str
    url: str


@dataclass(frozen=True)
class PaymentEvent:
    event_id: str
    external_id: str
    account: str
    amount_cents: int
    currency: str
    state: str
    occurred_at: float


@dataclass(frozen=True)
class Binding:
    tenant: str
    provider: str
    account: str
    webhook_secret: bytes
    checkout_hosts: frozenset[str]


class Gateway(Protocol):
    def create_checkout(self, *, account: str, amount_cents: int, currency: str,
                        idempotency_key: str) -> Checkout:
        """Hosted checkout; no diagnosis, symptoms, patient files or card data in metadata."""

    def verify_event(self, *, raw: bytes, headers: dict, secret: bytes, now: float) -> PaymentEvent:
        """Validate official signature, raw body and timestamp, then normalize the event."""


def verify_reference_hmac(raw: bytes, headers: dict, secret: bytes, now: float) -> PaymentEvent:
    """A tested HMAC fixture contract. It is not a real provider integration."""
    if not isinstance(raw, bytes) or len(raw) > 65536 or len(secret) < 32:
        raise ValueError('Invalid webhook envelope')
    timestamp = str(headers.get('x-event-timestamp', ''))
    signature = str(headers.get('x-event-signature', ''))
    if not timestamp.isdecimal() or len(timestamp) > 12:
        raise ValueError('Invalid webhook timestamp')
    sent_at = int(timestamp)
    if now - sent_at > 300 or sent_at - now > 30:
        raise ValueError('Webhook outside allowed time window')
    expected = hmac.new(secret, timestamp.encode() + b'.' + raw, hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, signature):
        raise ValueError('Invalid webhook signature')
    payload = json.loads(raw)
    if not isinstance(payload, dict) or set(payload) != {
            'event_id','external_id','account','amount_cents','currency','state','occurred_at'}:
        raise ValueError('Invalid webhook schema')
    event = PaymentEvent(**payload)
    validate_event(event, now)
    return event


def validate_event(event, now):
    if (not isinstance(event, PaymentEvent)
            or not isinstance(event.event_id, str) or not 1 <= len(event.event_id) <= 200
            or not isinstance(event.external_id, str) or not 1 <= len(event.external_id) <= 200
            or not isinstance(event.account, str) or not 1 <= len(event.account) <= 200
            or type(event.amount_cents) is not int or not 1 <= event.amount_cents <= 100_000_000
            or event.currency != 'BRL' or event.state not in ('paid','failed','cancelled','refunded')
            or type(event.occurred_at) not in (int,float)
            or not 0 < event.occurred_at <= now + 30):
        raise ValueError('Invalid normalized payment event')


class Payments:
    def __init__(self, portal: Portal, *, gateways=None, bindings=None):
        self.portal, self.store = portal, portal.store
        # Provisioned only by server configuration, never request/query parameters.
        self.gateways = dict(gateways or {})
        self.bindings = dict(bindings or {})
        accounts = {}
        for binding in self.bindings.values():
            if (not isinstance(binding, Binding) or not binding.tenant or not binding.provider or not binding.account
                    or not isinstance(binding.webhook_secret,bytes) or len(binding.webhook_secret) < 32
                    or not binding.checkout_hosts):
                raise ValueError('Invalid server gateway binding')
            account = (binding.provider,binding.account)
            if account in accounts and accounts[account] != binding.tenant:
                raise ValueError('Gateway account cannot be implicitly shared between businesses')
            accounts[account] = binding.tenant
        self.store.db.executescript('''
          CREATE TABLE IF NOT EXISTS portal_orders (
            tenant TEXT NOT NULL, id TEXT NOT NULL, subject_id TEXT NOT NULL,
            amount_cents INTEGER NOT NULL CHECK(amount_cents BETWEEN 1 AND 100000000),
            currency TEXT NOT NULL CHECK(currency='BRL'), created_by TEXT NOT NULL,
            PRIMARY KEY(tenant,id),
            FOREIGN KEY(tenant,subject_id) REFERENCES portal_subjects(tenant,id));
          CREATE TRIGGER IF NOT EXISTS portal_orders_immutable BEFORE UPDATE ON portal_orders
            BEGIN SELECT RAISE(ABORT,'issued order is immutable'); END;
          CREATE TABLE IF NOT EXISTS portal_payment_intents (
            tenant TEXT NOT NULL, id TEXT NOT NULL, order_id TEXT NOT NULL, subject_id TEXT NOT NULL,
            binding_id TEXT NOT NULL, provider TEXT NOT NULL, account TEXT NOT NULL,
            idempotency_key TEXT NOT NULL, external_id TEXT, checkout_url TEXT,
            state TEXT NOT NULL CHECK(state IN('creating','pending','unknown','paid','failed','cancelled','refunded')),
            last_event_at REAL NOT NULL DEFAULT 0, reconciliation_required INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY(tenant,id), UNIQUE(tenant,order_id), UNIQUE(tenant,subject_id,idempotency_key),
            UNIQUE(provider,account,external_id),
            FOREIGN KEY(tenant,order_id) REFERENCES portal_orders(tenant,id));
          CREATE TABLE IF NOT EXISTS portal_payment_events (
            binding_id TEXT NOT NULL, event_id TEXT NOT NULL, body_hash TEXT NOT NULL,
            intent_id TEXT NOT NULL, result TEXT NOT NULL, received_at REAL NOT NULL,
            PRIMARY KEY(binding_id,event_id));
        ''')

    def issue_order(self, token, tenant, subject_id, amount_cents):
        identity = self.portal.identify(token)
        if type(amount_cents) is not int or not 1 <= amount_cents <= 100_000_000:
            raise ValueError('Valor inválido em centavos.')
        with self.store.lock, self.store.db:
            allowed = (self.portal.staff_role(identity, tenant) in ('owner','finance')
                       and self.portal._subject(tenant, subject_id))
            self.portal._audit(identity, tenant, 'issue_order', subject_id, bool(allowed))
            if allowed:
                order_id = str(uuid4())
                self.store.db.execute('INSERT INTO portal_orders VALUES(?,?,?,?,?,?)',
                    (tenant,order_id,subject_id,amount_cents,'BRL',identity.user_id))
        if not allowed:
            raise AccessDenied('Acesso não autorizado.')
        return order_id

    def _binding(self, binding_id):
        binding = self.bindings.get(binding_id)
        if not binding or binding.provider not in self.gateways:
            raise GatewayDisabled('Pagamento indisponível até ativação e teste do provedor.')
        return binding, self.gateways[binding.provider]

    def checkout(self, token, tenant, order_id, binding_id, idempotency_key):
        """The browser supplies order ID only. Amount/currency come from a server-issued order."""
        identity = self.portal.identify(token)
        if not isinstance(idempotency_key, str) or not re.fullmatch(r'[A-Za-z0-9_-]{16,100}', idempotency_key):
            raise ValueError('Chave de repetição inválida.')
        binding, gateway = self._binding(binding_id)
        with self.store.lock, self.store.db:
            order = self.store.db.execute('SELECT * FROM portal_orders WHERE tenant=? AND id=?',
                                          (tenant,order_id)).fetchone()
            allowed = bool(order and binding.tenant == tenant and
                self.portal._owner(identity, tenant, order['subject_id']))
            self.portal._audit(identity, tenant, 'checkout', order_id, allowed)
            if allowed:
                previous = self.store.db.execute('''SELECT * FROM portal_payment_intents
                    WHERE tenant=? AND (order_id=? OR (subject_id=? AND idempotency_key=?))''',
                    (tenant,order_id,order['subject_id'],idempotency_key)).fetchall()
                if previous:
                    if len(previous) != 1 or previous[0]['order_id'] != order_id or previous[0]['binding_id'] != binding_id:
                        raise ValueError('Chave já associada a outra operação.')
                    return self._summary(previous[0])
                intent_id = str(uuid4())
                self.store.db.execute('''INSERT INTO portal_payment_intents
                    (tenant,id,order_id,subject_id,binding_id,provider,account,idempotency_key,state)
                    VALUES(?,?,?,?,?,?,?,?,?)''',
                    (tenant,intent_id,order_id,order['subject_id'],binding_id,binding.provider,
                     binding.account,idempotency_key,'creating'))
        if not allowed:
            raise AccessDenied('Acesso não autorizado.')
        # The intent commits before the external side effect. Concurrent/repeated requests
        # return its current state; unknown results are reconciled rather than charged again.
        try:
            result = gateway.create_checkout(account=binding.account, amount_cents=order['amount_cents'],
                currency=order['currency'], idempotency_key=intent_id)
            if not isinstance(result, Checkout):
                raise ValueError('Resposta do provedor inválida.')
            parsed = urlsplit(result.url)
            if (not result.external_id or len(result.external_id) > 200
                    or parsed.scheme != 'https' or parsed.hostname not in binding.checkout_hosts
                    or parsed.username or parsed.password or parsed.port not in (None,443)):
                raise ValueError('Resposta do provedor inválida.')
            with self.store.lock, self.store.db:
                self.store.db.execute('''UPDATE portal_payment_intents SET external_id=?,checkout_url=?,state='pending'
                    WHERE tenant=? AND id=? AND state='creating' ''',
                    (result.external_id,result.url,tenant,intent_id))
        except Exception:
            with self.store.lock, self.store.db:
                self.store.db.execute('''UPDATE portal_payment_intents SET state='unknown',reconciliation_required=1
                    WHERE tenant=? AND id=? AND state='creating' ''', (tenant,intent_id))
            # No provider exception is returned: it may contain secrets/customer information.
        with self.store.lock:
            return self._summary(self.store.db.execute(
                'SELECT * FROM portal_payment_intents WHERE tenant=? AND id=?', (tenant,intent_id)).fetchone())

    @staticmethod
    def _summary(row):
        return {'id': row['id'], 'state': row['state'], 'checkout_url': row['checkout_url'],
                'reconciliation_required': bool(row['reconciliation_required'])}

    def receive_webhook(self, binding_id, raw, headers):
        """No request-supplied tenant/amount can select or settle another business' order."""
        binding, gateway = self._binding(binding_id)
        if not isinstance(raw, bytes) or len(raw) > 65536:
            raise ValueError('Invalid webhook envelope')
        event = gateway.verify_event(raw=raw, headers=headers, secret=binding.webhook_secret, now=self.portal.now())
        validate_event(event, self.portal.now())
        # A valid shared/platform webhook secret does not identify the receiving merchant.
        # The merchant/account must come from verified provider evidence, never this route.
        if event.account != binding.account:
            raise ValueError('Verified event belongs to another gateway account')
        body_hash = hashlib.sha256(raw).hexdigest()
        with self.store.lock, self.store.db:
            previous = self.store.db.execute('SELECT * FROM portal_payment_events WHERE binding_id=? AND event_id=?',
                                             (binding_id,event.event_id)).fetchone()
            if previous:
                if previous['body_hash'] != body_hash:
                    raise ValueError('Event identity collision')
                return previous['result']
            row = self.store.db.execute('''SELECT i.*,o.amount_cents,o.currency FROM portal_payment_intents i
                JOIN portal_orders o ON o.tenant=i.tenant AND o.id=i.order_id
                WHERE i.tenant=? AND i.binding_id=? AND i.provider=? AND i.account=? AND i.external_id=?''',
                (binding.tenant,binding_id,binding.provider,binding.account,event.external_id)).fetchone()
            if not row or row['amount_cents'] != event.amount_cents or row['currency'] != event.currency:
                raise ValueError('Unmatched payment event; requires provider reconciliation')
            allowed = {'pending': {'paid','failed','cancelled'}, 'paid': {'refunded'},
                       'failed': set(), 'cancelled': set(), 'refunded': set()}
            monetary_conflict = ((row['state'] in ('failed','cancelled') and event.state == 'paid')
                                 or (row['state'] == 'pending' and event.state == 'refunded'))
            if monetary_conflict:
                # A late/out-of-order settlement must not vanish merely because its provider
                # timestamp predates a failure already observed. Reconcile with the gateway.
                self.store.db.execute('''UPDATE portal_payment_intents SET reconciliation_required=1
                    WHERE tenant=? AND id=?''', (binding.tenant,row['id']))
                result = 'reconciliation_required'
            elif event.occurred_at < row['last_event_at'] or event.state == row['state']:
                result = 'ignored'
            elif event.state in allowed.get(row['state'], set()):
                self.store.db.execute('''UPDATE portal_payment_intents SET state=?,last_event_at=?
                    WHERE tenant=? AND id=?''', (event.state,event.occurred_at,binding.tenant,row['id']))
                result = 'applied'
            elif row['state'] in ('paid','refunded') and event.state in ('failed','cancelled'):
                result = 'ignored'  # An old/late failure cannot undo settled money.
            else:
                self.store.db.execute('''UPDATE portal_payment_intents SET reconciliation_required=1
                    WHERE tenant=? AND id=?''', (binding.tenant,row['id']))
                result = 'reconciliation_required'
            self.store.db.execute('INSERT INTO portal_payment_events VALUES(?,?,?,?,?,?)',
                (binding_id,event.event_id,body_hash,row['id'],result,self.portal.now()))
            return result
