"""Planejamento editorial e publicação de versões explicitamente aprovadas."""
from datetime import datetime, timedelta, timezone
import os
import threading
from .publication import Publication, configured

CTAS={
    'psicologia':['Conheça as modalidades de atendimento.','Saiba como funciona o primeiro encontro.','Fale com a recepção para informações.'],
    'psiquiatria':['Conheça a formação e o registro profissional.','Saiba como funciona a consulta.','Fale com a recepção sobre disponibilidade.'],
    'hotel':['Conheça as acomodações.','Consulte disponibilidade para sua estadia.','Fale com a equipe e planeje sua visita.'],
    'motel':['Conheça as suítes e os períodos.','Consulte valores e disponibilidade com a recepção.','Confira as condições de reserva.'],
}


def instant(value):
    date=datetime.fromisoformat(value.replace('Z','+00:00'))
    if date.tzinfo is None:
        raise ValueError('Data editorial precisa incluir o fuso horário')
    return date


def generate_batch(hub,tenant,brand,brief,slots,channel='instagram',demo=True,delivery_mode='assisted'):
    if not 1 <= len(slots) <= 14:
        raise ValueError('Planeje de 1 a 14 publicações por lote')
    dates=[instant(value) for value in slots]
    if len(set(dates)) != len(dates):
        raise ValueError('Há horários repetidos no planejamento')
    if any(date <= datetime.now(timezone.utc) for date in dates):
        raise ValueError('Escolha horários futuros')
    if any(b-a < timedelta(minutes=60) for a,b in zip(sorted(dates),sorted(dates)[1:])):
        raise ValueError('Mantenha pelo menos uma hora entre publicações do lote')
    if delivery_mode=='automatic' and (demo or not configured(channel)):
        raise ValueError('Agendamento automático exige marca real e conta conectada')
    items=[]
    try:
        for index,value in enumerate(slots):
            cta=CTAS.get(brand['sector'],CTAS['hotel'])[index%3]
            topic=f'{brief}\nÂngulo editorial {index+1}: '+['apresentação de serviço','dúvida frequente','como funciona o atendimento','informação útil','detalhes do espaço','orientação para o primeiro contato','convite para conhecer'][index%7]
            items.append(hub.generate(tenant,brand,topic+'\nChamada para ação: '+cta,'text',value,channel,demo,delivery_mode))
    except Exception as error:
        # Não descartar propostas já geradas nem repetir chamadas pagas silenciosamente.
        return {'items':items,'partial':True,'error':str(error),'message':'Lote interrompido. Revise as propostas já criadas antes de tentar novamente.'}
    return {'items':items,'partial':False}


class Scheduler:
    def __init__(self,hub,publisher=None):
        self.hub=hub
        self.publisher=publisher or Publication(hub)
        self.thread=None

    def tick(self,tenant,now=None):
        now=now or datetime.now(timezone.utc)
        for item in self.hub.store.all(tenant,'marketing'):
            if item['status']!='approved' or not item.get('scheduled_at'):
                continue
            if item.get('publication_status') in ('published','reported_by_operator','sending','unknown','missed'):
                continue
            try:
                due=instant(item['scheduled_at'])
            except ValueError:
                continue
            if due>now:
                continue
            with self.hub.lock:
                current=self.hub.store.get(tenant,'marketing',item['id'])
                if not current or current['status']!='approved' or current.get('approved_hash')!=self.hub.fingerprint(current):
                    continue
                item=current
                due=instant(item['scheduled_at'])
                if due>now:
                    continue
                if item.get('delivery_mode')!='automatic':
                    item['publication_status']='awaiting_operator'
                    self.hub.store.put(tenant,'marketing',item['id'],item)
                    continue
                if now-due>timedelta(minutes=30):
                    item['publication_status']='missed'
                    self.hub.store.put(tenant,'marketing',item['id'],item)
                    self.hub.log(tenant,'missed_schedule',item['id'],'scheduler')
                    continue
            try:
                self.publisher.publish(tenant,item['id'])
            except ValueError:
                # Publicador guarda status desconhecido de tentativas ambíguas.
                # Sem conexão, a proposta aguarda operador; não dispara em outra conta.
                latest=self.hub.store.get(tenant,'marketing',item['id'])
                if latest.get('publication_status') not in ('unknown','published','sending'):
                    latest['publication_status']='awaiting_operator'
                    self.hub.store.put(tenant,'marketing',item['id'],latest)

    def start(self,tenant):
        if self.thread:
            return
        def run():
            while True:
                try:
                    self.tick(tenant)
                except Exception:
                    # Falha de base não autoriza publicação; manter o processo vivo.
                    pass
                threading.Event().wait(30)
        self.thread=threading.Thread(target=run,name='vereda-editorial',daemon=True)
        self.thread.start()
