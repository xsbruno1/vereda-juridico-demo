"""Pure preparation of reviewed case updates; no court login, scraping or I/O.

Call only behind authenticated, case-scoped authorization. This module does not
grant access or verify a court's truth. An approved connector must perform those
checks before supplying data; timestamps never imply automatic synchronization.
"""
from datetime import datetime, timedelta, timezone
from urllib.parse import urlsplit
import re

class InvalidCaseData(ValueError):
    pass

STAGES = frozenset({'recebimento', 'analise', 'providencia', 'audiencia', 'decisao', 'recurso', 'encerramento'})
COURT_HOSTS = frozenset({'www.tjsp.jus.br', 'esaj.tjsp.jus.br', 'eproc1g.tjsp.jus.br', 'eproc2g.tjsp.jus.br'})
SOURCES = frozenset({'professional_review', 'authorized_connector'})

def cnj_number(value):
    """Validate the CNJ Mod97-10 checksum, not existence or permission to access."""
    if not isinstance(value, str) or not re.fullmatch(r'(?:[0-9]{20}|[0-9]{7}-[0-9]{2}\.[0-9]{4}\.[1-9]\.[0-9]{2}\.[0-9]{4})', value):
        raise InvalidCaseData('Informe o número CNJ completo.')
    digits = value.replace('-', '').replace('.', '')
    if digits[13] == '0' or int(digits[:7] + digits[9:] + digits[7:9]) % 97 != 1:
        raise InvalidCaseData('Dígito verificador inválido.')
    return f'{digits[:7]}-{digits[7:9]}.{digits[9:13]}.{digits[13]}.{digits[14:16]}.{digits[16:]}'

def instant(value):
    try:
        if not isinstance(value, str) or len(value) > 40:
            raise ValueError()
        parsed = datetime.fromisoformat(value.replace('Z', '+00:00'))
        if parsed.tzinfo is None:
            raise ValueError()
        return parsed.astimezone(timezone.utc)
    except (ValueError, TypeError):
        raise InvalidCaseData('Data deve informar horário e fuso.') from None

def court_link(value):
    try:
        url = urlsplit(value)
        if (url.scheme != 'https' or url.hostname not in COURT_HOSTS or url.port not in (443, None)
                or url.username or url.password or url.query or url.fragment
                or re.search(r'[\s\\\x00-\x1f]', value)):
            raise ValueError()
    except (ValueError, TypeError, AttributeError):
        raise InvalidCaseData('Use somente uma página oficial aprovada, sem credenciais ou parâmetros.') from None
    return value

def text(value, limit):
    if not isinstance(value, str) or not value.strip() or len(value) > limit or re.search(r'[\x00-\x08\x0b\x0c\x0e-\x1f]', value):
        raise InvalidCaseData('Texto ausente ou inválido.')
    return value.strip()

def build_timeline(case, events, *, now, freshness_hours=72):
    """Return a non-linear timeline with source freshness and no outcome forecast.

    Inputs contain ONLY records already authorized for this principal and case.
    `released` is a display gate, never a replacement for backend authorization.
    A connector update still requires professional review before client display.
    """
    if set(case) != {'case_number', 'source_kind', 'source_url', 'checked_at', 'sync_state'}:
        raise InvalidCaseData('Campos não permitidos: não forneça senhas ou credenciais.')
    if case['source_kind'] not in SOURCES or case['sync_state'] not in {'manual', 'current', 'unavailable'}:
        raise InvalidCaseData('Origem ou sincronização inválida.')
    if case['source_kind'] == 'professional_review' and case['sync_state'] == 'current':
        raise InvalidCaseData('Revisão manual não equivale a sincronização automática.')
    if not isinstance(now, datetime) or now.tzinfo is None:
        raise InvalidCaseData('Relógio confiável com fuso obrigatório.')
    if isinstance(freshness_hours, bool) or not isinstance(freshness_hours, (int, float)) or not 1 <= freshness_hours <= 720:
        raise InvalidCaseData('Janela de atualização inválida.')
    number = cnj_number(case['case_number'])
    link = court_link(case['source_url'])
    checked = instant(case['checked_at'])
    if checked > now:
        raise InvalidCaseData('Conferência não pode estar no futuro.')
    if not isinstance(events, list) or len(events) > 500:
        raise InvalidCaseData('Lote de movimentações inválido.')
    seen, visible = set(), []
    fields = {'id', 'case_number', 'occurred_at', 'stage', 'title', 'summary', 'released', 'reviewed_at'}
    for item in events:
        if not isinstance(item, dict) or set(item) != fields:
            raise InvalidCaseData('Movimentação contém campos não permitidos.')
        if cnj_number(item['case_number']) != number:
            raise InvalidCaseData('Movimentação pertence a outro processo.')
        key = text(item['id'], 120)
        if key in seen:
            raise InvalidCaseData('Identificador duplicado; concilie a versão na origem.')
        seen.add(key)
        if type(item['released']) is not bool or item['stage'] not in STAGES:
            raise InvalidCaseData('Revisão ou etapa inválida.')
        occurred = instant(item['occurred_at'])
        if occurred > checked:
            raise InvalidCaseData('Movimentação posterior à última conferência.')
        if not item['released']:
            continue
        reviewed = instant(item['reviewed_at'])
        if reviewed < occurred or reviewed > now:
            raise InvalidCaseData('Revisão da movimentação inválida.')
        visible.append({'id': key, 'occurred_at': occurred.isoformat(), 'stage': item['stage'],
                        'title': text(item['title'], 150), 'summary': text(item['summary'], 1200),
                        'reviewed_at': reviewed.isoformat()})
    visible.sort(key=lambda event: (event['occurred_at'], event['id']))
    stale = now - checked > timedelta(hours=freshness_hours)
    return {'case_number': number, 'events': visible, 'source_url': link,
            'source_kind': case['source_kind'], 'checked_at': checked.isoformat(),
            'sync_state': case['sync_state'], 'needs_verification': stale or case['sync_state'] == 'unavailable',
            'notice': 'Etapas podem se repetir. Esta linha do tempo não prevê resultado, duração ou prazo processual.'}
