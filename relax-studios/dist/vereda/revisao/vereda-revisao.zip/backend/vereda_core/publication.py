"""Destinos sociais públicos. Não é envio de mensagem para contatos/leads."""
import json
import os
import re
import urllib.request
from urllib.parse import urlparse

NETWORKS={
    'instagram':{'label':'Instagram','url':'https://www.instagram.com/','hosts':('instagram.com','www.instagram.com')},
    'facebook':{'label':'Facebook','url':'https://www.facebook.com/','hosts':('facebook.com','www.facebook.com')},
    'google_business':{'label':'Perfil da Empresa no Google','url':'https://business.google.com/','hosts':('business.google.com','maps.google.com','www.google.com','google.com','maps.app.goo.gl')},
}


def available():
    return [{**{k:v for k,v in data.items() if k!='hosts'},'id':key,
             'account':os.environ.get('VEREDA_FACEBOOK_PAGE_NAME',destination(key)) if key=='facebook' else (os.environ.get('VEREDA_GOOGLE_LOCATION_NAME',destination(key)) if key=='google_business' else None),
             'connected':configured(key),'method':'official' if configured(key) else 'assisted'} for key,data in NETWORKS.items()]


def configured(channel):
    if channel=='facebook':
        return bool(os.environ.get('VEREDA_FACEBOOK_TOKEN') and re.fullmatch(r'\d+',os.environ.get('VEREDA_FACEBOOK_PAGE_ID',''))
                    and re.fullmatch(r'v\d+\.\d+',os.environ.get('VEREDA_META_API_VERSION','')))
    if channel=='google_business':
        return bool(os.environ.get('VEREDA_GOOGLE_TOKEN') and re.fullmatch(r'accounts/\d+/locations/\d+',os.environ.get('VEREDA_GOOGLE_LOCATION','')))
    return False


class Publication:
    def __init__(self,hub,transport=None):
        self.hub=hub
        self.transport=transport or self._post

    @staticmethod
    def _post(url,payload,token):
        req=urllib.request.Request(url,data=json.dumps(payload).encode(),headers={'Content-Type':'application/json','Authorization':'Bearer '+token})
        with urllib.request.urlopen(req,timeout=30) as response:
            return json.load(response)

    def publish(self,tenant,identifier):
        with self.hub.lock:
            item=self.hub.store.get(tenant,'marketing',identifier)
            if not item:
                raise ValueError('Proposta não encontrada')
            if item.get('publication_status') in ('published','sending','unknown'):
                raise ValueError('Envio já realizado ou resultado pendente de conferência. Evite duplicação.')
            if item.get('demo',True):
                raise ValueError('Marca demonstrativa não pode ser publicada automaticamente')
            channel=item.get('channel','instagram')
            self.hub.export(tenant,identifier)  # A mesma barreira obrigatória de aprovação.
            if not configured(channel):
                raise ValueError('Rede sem conexão autorizada. Use a publicação assistida.')
            if item.get('asset'):
                raise ValueError('Imagem: use o pacote assistido até configurar o envio de mídia da conta')
            # Mudança de conexão após aprovação exige revisão explícita do destino.
            if item.get('destination') != destination(channel):
                raise ValueError('Conta de destino mudou. Gere e aprove uma nova versão.')
            item['publication_status']='sending'
            self.hub.store.put(tenant,'marketing',identifier,item)
            try:
                if channel=='facebook':
                    url='https://graph.facebook.com/'+os.environ['VEREDA_META_API_VERSION']+'/'+os.environ['VEREDA_FACEBOOK_PAGE_ID']+'/feed'
                    response=self.transport(url,{'message':item['text']},os.environ['VEREDA_FACEBOOK_TOKEN'])
                    receipt=response.get('id')
                elif channel=='google_business':
                    response=self.transport('https://mybusiness.googleapis.com/v4/'+os.environ['VEREDA_GOOGLE_LOCATION']+'/localPosts',
                        {'languageCode':'pt-BR','summary':item['text'],'topicType':'STANDARD'},os.environ['VEREDA_GOOGLE_TOKEN'])
                    receipt=response.get('name')
                else:
                    raise ValueError('Rede disponível apenas no modo assistido')
                if not receipt:
                    raise ValueError('A rede não confirmou o envio')
                item.update(publication_status='published',publication_receipt=receipt)
                self.hub.log(tenant,'published_official',identifier,item['reviewer'])
            except Exception:
                item['publication_status']='unknown'
                self.hub.store.put(tenant,'marketing',identifier,item)
                raise ValueError('Resultado do envio precisa ser conferido na rede antes de tentar novamente') from None
            self.hub.store.put(tenant,'marketing',identifier,item)
            return {'status':'published','receipt':receipt}

    def confirm_assisted(self,tenant,identifier,url):
        item=self.hub.store.get(tenant,'marketing',identifier)
        if not item:
            raise ValueError('Proposta não encontrada')
        self.hub.export(tenant,identifier)
        channel=item.get('channel','instagram')
        parsed=urlparse(url)
        if parsed.scheme!='https' or parsed.hostname not in NETWORKS[channel]['hosts'] or parsed.path in ('','/'):
            raise ValueError('Informe o link HTTPS da publicação na rede escolhida')
        item.update(publication_status='reported_by_operator',publication_url=url)
        self.hub.store.put(tenant,'marketing',identifier,item)
        self.hub.log(tenant,'manual_publication_reported',identifier,item['reviewer'])
        return {'status':'reported_by_operator','url':url}


def destination(channel):
    return os.environ.get('VEREDA_FACEBOOK_PAGE_ID') if channel=='facebook' else (os.environ.get('VEREDA_GOOGLE_LOCATION') if channel=='google_business' else None)
