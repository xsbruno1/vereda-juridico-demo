import hashlib
import hmac
import json
import sqlite3
import threading
import time
import unittest
from concurrent.futures import ThreadPoolExecutor

from cryptography.exceptions import InvalidTag

from vereda_core.client_portal.core import AccessDenied, Identity, Portal, Store
from vereda_core.client_portal.payments import (
    Binding, Checkout, GatewayDisabled, Payments, verify_reference_hmac,
)


class TestVerifier:
    __test__ = False
    def __init__(self, now):
        self.now, self.revoked = now, set()

    def verify(self, token):
        if token in self.revoked or token not in {
                'alice','bob','other','dentist','lawyer','owner','reception','finance','external','low_mfa'}:
            raise AccessDenied('Invalid test session')
        return Identity('dentist' if token == 'low_mfa' else token, 'session-'+token,
                        self.now()+3600, 'aal1' if token == 'low_mfa' else 'aal2')


class FixtureGateway:
    """Tests only. Not shipped as an operational payment integration."""
    def __init__(self):
        self.calls = []
        self.timeout = False
        self.url = 'https://checkout.example.test/pay/fixture'
        self.lock = threading.Lock()

    def create_checkout(self, **kwargs):
        with self.lock:
            self.calls.append(kwargs)
        time.sleep(.01)
        if self.timeout:
            raise TimeoutError('provider result unknown')
        return Checkout('external-'+kwargs['idempotency_key'], self.url)

    verify_event = staticmethod(verify_reference_hmac)


class PortalFixture(unittest.TestCase):
    def setUp(self):
        self.clock = [1_000_000.]
        self.now = lambda: self.clock[0]
        self.store = Store(lambda tenant, version: hashlib.sha256(f'{tenant}:{version}:test-only'.encode()).digest())
        self.addCleanup(self.store.close)
        self.verifier = TestVerifier(self.now)
        self.portal = Portal(self.store, self.verifier, self.now)
        with self.store.db:
            self.store.db.executemany('INSERT INTO portal_subjects VALUES(?,?,?,1)',
                [('a','s-alice','alice'),('a','s-bob','bob'),('b','s-other','other')])
            self.store.db.executemany('INSERT INTO portal_memberships VALUES(?,?,?,1)',
                [('a','dentist','clinician'),('a','lawyer','lawyer'),('a','owner','owner'),
                 ('a','reception','reception'),('a','finance','finance')])
            self.store.db.executemany('INSERT INTO portal_assignments VALUES(?,?,?)',
                [('a','s-alice','dentist'),('a','s-alice','lawyer')])
        self.record = self.portal.create_record('dentist','a','s-alice','clinical',
                                                {'note':'Dado clínico fictício sensível'})

    def released(self):
        self.portal.release_record('dentist','a',self.record)
        return self.record


class AccessTests(PortalFixture):
    def test_patient_cannot_read_unreleased_but_can_request_complete_copy(self):
        with self.assertRaises(AccessDenied):
            self.portal.read_record('alice','a',self.record)
        result = self.portal.request_complete_copy('alice','a','s-alice')
        self.assertEqual(result['status'],'requested')
        self.assertEqual(self.store.db.execute('SELECT count(*) FROM portal_access_requests').fetchone()[0],1)

    def test_patient_reads_own_released_record(self):
        self.released()
        self.assertIn('note',self.portal.read_record('alice','a',self.record))

    def test_other_patient_same_business_is_denied(self):
        self.released()
        with self.assertRaises(AccessDenied): self.portal.read_record('bob','a',self.record)

    def test_other_business_is_denied(self):
        self.released()
        with self.assertRaises(AccessDenied): self.portal.read_record('other','a',self.record)
        with self.assertRaises(AccessDenied): self.portal.read_record('alice','b',self.record)

    def test_reception_owner_finance_and_lawyer_cannot_read_clinical(self):
        for role in ('reception','owner','finance','lawyer'):
            with self.subTest(role=role), self.assertRaises(AccessDenied):
                self.portal.read_record(role,'a',self.record)

    def test_assignment_and_membership_revocation_are_immediate(self):
        self.portal.read_record('dentist','a',self.record)
        with self.store.db: self.store.db.execute('DELETE FROM portal_assignments WHERE user_id=?',('dentist',))
        with self.assertRaises(AccessDenied): self.portal.read_record('dentist','a',self.record)
        with self.store.db:
            self.store.db.execute('INSERT INTO portal_assignments VALUES(?,?,?)',('a','s-alice','dentist'))
            self.store.db.execute('UPDATE portal_memberships SET active=0 WHERE user_id=?',('dentist',))
        with self.assertRaises(AccessDenied): self.portal.read_record('dentist','a',self.record)

    def test_sensitive_staff_requires_mfa(self):
        with self.assertRaises(AccessDenied): self.portal.read_record('low_mfa','a',self.record)

    def test_session_revocation_is_checked_every_operation(self):
        self.verifier.revoked.add('dentist')
        with self.assertRaises(AccessDenied): self.portal.read_record('dentist','a',self.record)

    def test_missing_identity_is_denied(self):
        for value in ('','{"role":"owner"}', 'invented'):
            with self.assertRaises(AccessDenied): self.portal.read_record(value,'a',self.record)

    def test_administrative_and_legal_data_are_separate(self):
        admin = self.portal.create_record('reception','a','s-alice','administrative',{'appointment_id':'example'})
        self.assertIn('appointment_id',self.portal.read_record('reception','a',admin))
        legal = self.portal.create_record('lawyer','a','s-alice','legal',{'case':'fiction'})
        with self.assertRaises(AccessDenied): self.portal.read_record('dentist','a',legal)

    def test_unassigned_clinician_cannot_write_other_patient(self):
        with self.assertRaises(AccessDenied):
            self.portal.create_record('dentist','a','s-bob','clinical',{'note':'denied'})

    def test_only_authorized_professional_can_release(self):
        for token in ('alice','reception','owner','other'):
            with self.assertRaises(AccessDenied): self.portal.release_record(token,'a',self.record)

    def test_records_are_encrypted_and_bound_to_subject(self):
        row = self.store.db.execute('SELECT ciphertext FROM portal_records').fetchone()
        self.assertNotIn('Dado clínico fictício sensível'.encode(),row[0])
        other = self.portal.create_record('dentist','a','s-alice','clinical',{'note':'another'})
        with self.store.db:
            self.store.db.execute('UPDATE portal_records SET ciphertext=? WHERE id=?',(row[0],other))
        with self.assertRaises(InvalidTag): self.portal.read_record('dentist','a',other)

    def test_denials_are_audited_without_record_content(self):
        with self.assertRaises(AccessDenied): self.portal.read_record('other','a',self.record)
        values = [dict(r) for r in self.store.db.execute('SELECT * FROM portal_audit')]
        self.assertEqual(values[-1]['outcome'],'denied')
        self.assertNotIn('sensível',json.dumps(values,ensure_ascii=False))
        with self.assertRaises(sqlite3.IntegrityError): self.store.db.execute('DELETE FROM portal_audit')

    def test_sharing_requires_released_record_and_owner(self):
        with self.assertRaises(AccessDenied): self.portal.create_share('alice','a',self.record,'external','view')
        self.released()
        with self.assertRaises(AccessDenied): self.portal.create_share('bob','a',self.record,'external','view')

    def test_share_is_bound_to_recipient_and_action(self):
        self.released()
        token = self.portal.create_share('alice','a',self.record,'external','view')
        self.assertIn('note',self.portal.read_share('external',token,'view'))
        with self.assertRaises(AccessDenied): self.portal.read_share('bob',token,'view')
        with self.assertRaises(AccessDenied): self.portal.read_share('external',token,'download')
        self.assertNotIn(token, str([tuple(r) for r in self.store.db.execute('SELECT * FROM portal_shares')]))

    def test_share_expires_and_can_be_revoked(self):
        self.released()
        token = self.portal.create_share('alice','a',self.record,'external','download',lifetime=10)
        self.clock[0] += 11
        with self.assertRaises(AccessDenied): self.portal.read_share('external',token,'download')
        token = self.portal.create_share('alice','a',self.record,'external','view')
        with self.assertRaises(AccessDenied): self.portal.revoke_share('bob',token)
        self.portal.revoke_share('alice',token)
        with self.assertRaises(AccessDenied): self.portal.read_share('external',token,'view')

    def test_subject_deactivation_revokes_shares(self):
        self.released()
        token = self.portal.create_share('alice','a',self.record,'external','view')
        with self.store.db: self.store.db.execute("UPDATE portal_subjects SET active=0 WHERE id='s-alice'")
        with self.assertRaises(AccessDenied): self.portal.read_share('external',token,'view')

    def test_copy_request_cannot_target_other_patient(self):
        with self.assertRaises(AccessDenied): self.portal.request_complete_copy('alice','a','s-bob')

    def test_administrative_free_text_clinical_fields_are_rejected(self):
        with self.assertRaises(ValueError):
            self.portal.create_record('reception','a','s-alice','administrative',{'diagnosis':'private'})

    def test_nan_session_expiry_is_rejected(self):
        self.verifier.verify = lambda _: Identity('alice','id',float('nan'),'aal2')
        with self.assertRaises(AccessDenied): self.portal.read_record('alice','a',self.record)

    def test_missing_or_short_encryption_key_is_rejected(self):
        self.store.key_resolver = lambda tenant, version: b'a'*16
        with self.assertRaises(ValueError):
            self.portal.create_record('dentist','a','s-alice','clinical',{'note':'example'})


class InvitationTests(PortalFixture):
    def setUp(self):
        super().setUp()
        with self.store.db:
            self.store.db.execute("UPDATE portal_subjects SET active=0 WHERE id='s-bob'")

    def test_invite_is_bound_to_verified_recipient_and_business(self):
        invite = self.portal.create_invite('owner','a','s-bob')
        with self.assertRaises(AccessDenied): self.portal.accept_invite('alice','a',invite)
        with self.assertRaises(AccessDenied): self.portal.accept_invite('bob','b',invite)
        result = self.portal.accept_invite('bob','a',invite)
        self.assertEqual(result,{'subject_id':'s-bob','status':'active'})
        self.assertEqual(self.store.db.execute("SELECT count(*) FROM portal_memberships WHERE user_id='bob'").fetchone()[0],0)
        self.assertNotIn(invite,str([tuple(r) for r in self.store.db.execute('SELECT * FROM portal_invites')]))

    def test_invite_is_single_use(self):
        invite = self.portal.create_invite('owner','a','s-bob')
        self.portal.accept_invite('bob','a',invite)
        with self.assertRaises(AccessDenied): self.portal.accept_invite('bob','a',invite)

    def test_expired_invite_is_rejected(self):
        invite = self.portal.create_invite('owner','a','s-bob',lifetime=5)
        self.clock[0] += 6
        with self.assertRaises(AccessDenied): self.portal.accept_invite('bob','a',invite)

    def test_reissued_invite_revokes_previous(self):
        old = self.portal.create_invite('owner','a','s-bob')
        new = self.portal.create_invite('owner','a','s-bob')
        with self.assertRaises(AccessDenied): self.portal.accept_invite('bob','a',old)
        self.portal.accept_invite('bob','a',new)

    def test_client_reception_and_other_tenant_cannot_issue_invites(self):
        for token in ('alice','reception','dentist','other'):
            with self.assertRaises(AccessDenied): self.portal.create_invite(token,'a','s-bob')
        with self.assertRaises(AccessDenied): self.portal.create_invite('owner','b','s-other')


class PaymentTests(PortalFixture):
    def setUp(self):
        super().setUp()
        self.gateway = FixtureGateway()
        self.binding = Binding('a','fixture','account-a',b'a'*32,frozenset({'checkout.example.test'}))
        self.payment = Payments(self.portal, gateways={'fixture':self.gateway}, bindings={
            'binding-a':self.binding,
            'binding-b':Binding('b','fixture','account-b',b'b'*32,frozenset({'checkout.example.test'})),
        })
        self.order = self.payment.issue_order('finance','a','s-alice',12000)

    def checkout(self, key='test-checkout-key-001'):
        return self.payment.checkout('alice','a',self.order,'binding-a',key)

    def event(self, *, state='paid', amount=12000, event_id='ev-1', occurred=None):
        row = self.store.db.execute('SELECT * FROM portal_payment_intents').fetchone()
        body = json.dumps({'event_id':event_id,'external_id':row['external_id'],'account':'account-a',
            'amount_cents':amount,'currency':'BRL','state':state,
            'occurred_at':occurred or self.now()}).encode()
        stamp = str(int(self.now()))
        headers = {'x-event-timestamp':stamp,'x-event-signature':hmac.new(
            self.binding.webhook_secret,stamp.encode()+b'.'+body,hashlib.sha256).hexdigest()}
        return body,headers

    def test_gateway_disabled_by_default(self):
        disabled = Payments(self.portal)
        with self.assertRaises(GatewayDisabled): disabled.checkout('alice','a',self.order,'binding-a','test-checkout-key-001')

    def test_patient_cannot_issue_or_change_order_price(self):
        with self.assertRaises(AccessDenied): self.payment.issue_order('alice','a','s-alice',1)
        with self.assertRaises(sqlite3.IntegrityError):
            self.store.db.execute('UPDATE portal_orders SET amount_cents=1')
        self.store.db.rollback()
        self.checkout()
        self.assertEqual(self.gateway.calls[0]['amount_cents'],12000)
        self.assertEqual(set(self.gateway.calls[0]),{'account','amount_cents','currency','idempotency_key'})

    def test_cross_patient_and_cross_binding_checkout_denied(self):
        with self.assertRaises(AccessDenied): self.payment.checkout('bob','a',self.order,'binding-a','test-checkout-key-001')
        with self.assertRaises(AccessDenied): self.payment.checkout('alice','a',self.order,'binding-b','test-checkout-key-001')
        self.assertEqual(self.gateway.calls,[])

    def test_repeated_and_concurrent_checkout_does_not_charge_twice(self):
        with ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(lambda _:self.checkout(),range(2)))
        self.assertEqual(len(self.gateway.calls),1)
        self.assertEqual(results[0]['id'],results[1]['id'])
        self.assertEqual(self.checkout('different-key-001')['id'],results[0]['id'])

    def test_idempotency_cannot_be_reused_for_different_order(self):
        self.checkout()
        order2 = self.payment.issue_order('finance','a','s-alice',15000)
        with self.assertRaises(ValueError):
            self.payment.checkout('alice','a',order2,'binding-a','test-checkout-key-001')

    def test_timeout_is_unknown_and_not_reissued(self):
        self.gateway.timeout = True
        result = self.checkout()
        self.assertEqual(result['state'],'unknown')
        self.assertTrue(result['reconciliation_required'])
        self.checkout()
        self.assertEqual(len(self.gateway.calls),1)

    def test_untrusted_checkout_url_is_not_exposed(self):
        self.gateway.url = 'https://attacker.example/pay'
        result = self.checkout()
        self.assertEqual(result['state'],'unknown')
        self.assertIsNone(result['checkout_url'])

    def test_valid_webhook_applies_once(self):
        self.checkout()
        body,headers = self.event()
        self.assertEqual(self.payment.receive_webhook('binding-a',body,headers),'applied')
        self.assertEqual(self.payment.receive_webhook('binding-a',body,headers),'applied')
        self.assertEqual(self.store.db.execute('SELECT count(*) FROM portal_payment_events').fetchone()[0],1)
        self.assertEqual(self.checkout()['state'],'paid')

    def test_signature_tampering_and_old_delivery_are_rejected(self):
        self.checkout()
        body,headers = self.event()
        with self.assertRaises(ValueError): self.payment.receive_webhook('binding-a',body+b' ',headers)
        self.clock[0] += 301
        with self.assertRaises(ValueError): self.payment.receive_webhook('binding-a',body,headers)

    def test_wrong_account_and_amount_cannot_settle(self):
        self.checkout()
        body,headers = self.event()
        with self.assertRaises(ValueError): self.payment.receive_webhook('binding-b',body,headers)
        body,headers = self.event(amount=1)
        with self.assertRaises(ValueError): self.payment.receive_webhook('binding-a',body,headers)
        self.assertEqual(self.checkout()['state'],'pending')

    def test_paid_payment_never_regresses_to_failed(self):
        self.checkout()
        self.payment.receive_webhook('binding-a',*self.event())
        self.clock[0] += 1
        self.assertEqual(self.payment.receive_webhook('binding-a',*self.event(state='failed',event_id='ev-2')),'ignored')
        self.assertEqual(self.checkout()['state'],'paid')

    def test_out_of_order_refund_requires_reconciliation(self):
        self.checkout()
        result = self.payment.receive_webhook('binding-a',*self.event(state='refunded'))
        self.assertEqual(result,'reconciliation_required')
        self.assertEqual(self.checkout()['state'],'pending')
        self.assertTrue(self.checkout()['reconciliation_required'])

    def test_valid_refund_follows_paid(self):
        self.checkout()
        self.payment.receive_webhook('binding-a',*self.event())
        self.clock[0] += 1
        self.payment.receive_webhook('binding-a',*self.event(state='refunded',event_id='ev-2'))
        self.assertEqual(self.checkout()['state'],'refunded')

    def test_event_id_collision_is_rejected(self):
        self.checkout()
        self.payment.receive_webhook('binding-a',*self.event())
        with self.assertRaises(ValueError):
            self.payment.receive_webhook('binding-a',*self.event(state='refunded'))

    def test_gateway_account_cannot_be_shared_across_businesses(self):
        with self.assertRaises(ValueError):
            Payments(self.portal,gateways={'fixture':self.gateway},bindings={
                'a':self.binding,
                'b':Binding('b','fixture','account-a',b'b'*32,frozenset({'checkout.example.test'}))})

    def test_shared_secret_cannot_replay_event_to_another_merchant(self):
        self.payment.bindings['binding-b'] = Binding('b','fixture','account-b',self.binding.webhook_secret,
                                                    frozenset({'checkout.example.test'}))
        self.gateway.create_checkout = lambda **kwargs: Checkout('merchant-scoped-001',self.gateway.url)
        self.checkout()
        with self.store.db:
            self.store.db.execute("INSERT INTO portal_memberships VALUES('b','finance','finance',1)")
        order_b = self.payment.issue_order('finance','b','s-other',12000)
        self.payment.checkout('other','b',order_b,'binding-b','merchant-b-key-001')
        body,headers = self.event()
        with self.assertRaises(ValueError): self.payment.receive_webhook('binding-b',body,headers)
        result = self.payment.checkout('other','b',order_b,'binding-b','merchant-b-key-001')
        self.assertEqual(result['state'],'pending')

    def test_older_paid_event_after_newer_failure_requires_reconciliation(self):
        self.checkout()
        self.payment.receive_webhook('binding-a',*self.event(state='failed',event_id='failure'))
        self.clock[0] += 1
        result = self.payment.receive_webhook('binding-a',*self.event(
            state='paid',event_id='older-settlement',occurred=self.now()-100))
        self.assertEqual(result,'reconciliation_required')
        self.assertTrue(self.checkout()['reconciliation_required'])


if __name__ == '__main__':
    unittest.main()
