import unittest
from datetime import datetime, timezone, timedelta
from vereda_core.case_timeline import cnj_number, court_link, build_timeline, InvalidCaseData

def number(sequence='1000001'):
    body = sequence + '2026' + '8' + '26' + '0100'
    check = 98 - int(body + '00') % 97
    return sequence + f'{check:02}' + '20268260100'

class TimelineTests(unittest.TestCase):
    def setUp(self):
        self.now = datetime(2026, 10, 25, 15, tzinfo=timezone.utc)
        self.case = dict(case_number=number(), source_kind='professional_review',
                         source_url='https://www.tjsp.jus.br/', checked_at='2026-10-25T12:00:00-03:00', sync_state='manual')
        self.event = dict(id='evt-1', case_number=number(), occurred_at='2026-10-24T12:00:00-03:00',
                          stage='analise', title='Documento recebido', summary='A equipe revisou o documento.',
                          released=True, reviewed_at='2026-10-25T10:00:00-03:00')
    def build(self, events=None):
        return build_timeline(self.case, events if events is not None else [self.event], now=self.now)
    def test_cnj_validation_and_format(self):
        result = cnj_number(number())
        self.assertEqual(cnj_number(result), result)
        with self.assertRaises(InvalidCaseData): cnj_number('1000001-00.2026.8.26.0100')
    def test_invalid_inputs(self):
        for value in ['1', None, '<script>', number() + ' ', '１' * 20]:
            with self.assertRaises(InvalidCaseData): cnj_number(value)
    def test_reject_credentials_and_query_urls(self):
        for link in ['http://www.tjsp.jus.br/', 'https://www.tjsp.jus.br.evil.example/',
                     'https://user:password@www.tjsp.jus.br/', 'https://esaj.tjsp.jus.br/?senha=123',
                     'https://www.tjsp.jus.br/#token', 'https://www.tjsp.jus.br:8443/']:
            with self.assertRaises(InvalidCaseData): court_link(link)
    def test_reject_extra_password_field(self):
        self.case['password'] = 'never-collect'
        with self.assertRaises(InvalidCaseData): self.build()
    def test_no_other_case(self):
        self.event['case_number'] = number('1000002')
        with self.assertRaises(InvalidCaseData): self.build()
    def test_unreleased_hidden(self):
        self.event.update(released=False, reviewed_at=None)
        self.assertEqual(self.build()['events'], [])
    def test_review_and_timezone_required(self):
        for value in [None, '2026-10-25T13:00:00', '2026-10-26T00:00:00Z']:
            self.event['reviewed_at'] = value
            with self.assertRaises(InvalidCaseData): self.build()
    def test_duplicates_fail_closed(self):
        with self.assertRaises(InvalidCaseData): self.build([self.event, dict(self.event)])
    def test_repeated_stage_not_progress_percentage(self):
        newer = dict(self.event, id='evt-2', occurred_at='2026-10-25T09:00:00-03:00')
        result = self.build([newer, self.event])
        self.assertEqual([x['id'] for x in result['events']], ['evt-1', 'evt-2'])
        self.assertNotIn('percent', result)
    def test_stale_and_unavailable_explicit(self):
        self.case['checked_at'] = '2026-10-20T12:00:00Z'
        self.assertTrue(self.build([])['needs_verification'])
        self.case['checked_at'] = self.now.isoformat()
        self.case['sync_state'] = 'unavailable'
        self.assertTrue(self.build()['needs_verification'])
    def test_manual_not_automatic(self):
        self.case['sync_state'] = 'current'
        with self.assertRaises(InvalidCaseData): self.build()
    def test_future_source_rejected(self):
        self.case['checked_at'] = (self.now + timedelta(seconds=1)).isoformat()
        with self.assertRaises(InvalidCaseData): self.build()
    def test_released_boolean_strict(self):
        self.event['released'] = 'false'
        with self.assertRaises(InvalidCaseData): self.build()

if __name__ == '__main__': unittest.main()
