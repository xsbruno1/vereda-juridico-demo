import hashlib
import json
import sqlite3
import unittest
from concurrent.futures import ThreadPoolExecutor
from dataclasses import replace

from cryptography.exceptions import InvalidTag

from vereda_core.client_portal.core import AccessDenied, Identity, Portal, Store
from vereda_core.client_portal.consultation import (
    Consultations, JoinGrant, RateLimited, VideoBinding, VideoDisabled, VideoRevocationPending,
    render_message_text,
)


class SessionFixture:
    def __init__(self, now):
        self.now, self.revoked = now, set()
        self.users = {'alice', 'bob', 'other', 'dentist', 'dentist2', 'lawyer', 'reception', 'owner'}

    def verify(self, token):
        if token in self.revoked or token not in self.users | {'low_mfa', 'expired'}:
            raise AccessDenied('Sessão fictícia inválida')
        user = 'dentist' if token == 'low_mfa' else token
        expires = self.now() - 1 if token == 'expired' else self.now() + 3600
        return Identity(user, 'session-' + token, expires, 'aal1' if token in ('alice', 'low_mfa') else 'aal2')


class ProviderFixture:
    """Opaque fake grant; never a real provider credential or JWT."""
    name = 'fixture'

    def __init__(self):
        self.calls, self.revoked = [], []
        self.ejected, self.closed = [], []
        self.after_issue = None
        self.transform = lambda grant: grant

    def issue(self, request):
        self.calls.append(request)
        grant = JoinGrant('opaque-fixture-token-only', request.external_room_id,
                          request.participant_id, request.expires_at)
        if self.after_issue:
            self.after_issue()
        return self.transform(grant)

    def revoke(self, grant):
        self.revoked.append(grant)

    def eject(self, external_room_id, participant_id):
        self.ejected.append((external_room_id, participant_id))

    def close_room(self, external_room_id):
        self.closed.append(external_room_id)


class ConsultationTests(unittest.TestCase):
    def setUp(self):
        self.clock = [1_000_000.0]
        self.now = lambda: self.clock[0]
        self.store = Store(lambda tenant, version: hashlib.sha256(
            f'test-only:{tenant}:{version}'.encode()).digest())
        self.addCleanup(self.store.close)
        self.verifier = SessionFixture(self.now)
        self.portal = Portal(self.store, self.verifier, self.now)
        with self.store.db:
            self.store.db.executemany('INSERT INTO portal_subjects VALUES(?,?,?,1)',
                [('a', 's-alice', 'alice'), ('a', 's-bob', 'bob'), ('b', 's-other', 'other')])
            self.store.db.executemany('INSERT INTO portal_memberships VALUES(?,?,?,1)',
                [('a', 'dentist', 'clinician'), ('a', 'dentist2', 'clinician'),
                 ('a', 'lawyer', 'lawyer'), ('a', 'reception', 'reception'), ('a', 'owner', 'owner')])
            self.store.db.executemany('INSERT INTO portal_assignments VALUES(?,?,?)',
                [('a', 's-alice', 'dentist'), ('a', 's-alice', 'dentist2'),
                 ('a', 's-alice', 'lawyer'), ('a', 's-bob', 'dentist')])
        self.rooms = Consultations(self.portal)
        self.room = self.rooms.create('dentist', 'a', 's-alice', 'clinical')
        self.record = self.portal.create_record('dentist', 'a', 's-alice', 'clinical',
                                                {'note': 'Exame fictício privado'})

    def release_attach(self):
        self.portal.release_record('dentist', 'a', self.record)
        return self.rooms.attach_record('dentist', 'a', self.room, self.record)

    def enable_video(self):
        self.video = ProviderFixture()
        self.rooms.provider = self.video
        self.rooms.binding_resolver = lambda tenant, room: (
            VideoBinding('fixture', 'server-controlled-room') if (tenant, room) == ('a', self.room) else None)

    def test_patient_and_assigned_host_exchange_plain_text(self):
        sent = self.rooms.send('alice', 'a', self.room, 'Minha dúvida fictícia', 'msg-1')
        self.rooms.send('dentist', 'a', self.room, 'Vou conferir o exame.', 'msg-2')
        messages = self.rooms.messages('alice', 'a', self.room)
        self.assertEqual(len(messages), 2)
        self.assertEqual(messages[0], sent)

    def test_another_patient_and_another_tenant_denied(self):
        for token, tenant in [('bob', 'a'), ('other', 'b'), ('alice', 'b')]:
            with self.subTest(token=token, tenant=tenant), self.assertRaises(AccessDenied):
                self.rooms.messages(token, tenant, self.room)

    def test_patient_cannot_create_room_or_enroll_others(self):
        with self.assertRaises(AccessDenied):
            self.rooms.create('alice', 'a', 's-alice', 'clinical')
        with self.assertRaises(AccessDenied):
            self.rooms.add_professional('alice', 'a', self.room, 'dentist2')

    def test_wrong_category_and_unassigned_host_denied(self):
        for token, subject, category in [('lawyer', 's-alice', 'clinical'),
                                          ('dentist', 's-alice', 'legal'),
                                          ('dentist2', 's-bob', 'clinical')]:
            with self.subTest(token=token), self.assertRaises(AccessDenied):
                self.rooms.create(token, 'a', subject, category)

    def test_reception_owner_and_lawyer_cannot_read_clinical_chat(self):
        for token in ('reception', 'owner', 'lawyer'):
            with self.subTest(token=token), self.assertRaises(AccessDenied):
                self.rooms.messages(token, 'a', self.room)
            with self.subTest(enroll=token), self.assertRaises(AccessDenied):
                self.rooms.add_professional('dentist', 'a', self.room, token)

    def test_assigned_professional_requires_explicit_membership(self):
        with self.assertRaises(AccessDenied):
            self.rooms.messages('dentist2', 'a', self.room)
        self.rooms.add_professional('dentist', 'a', self.room, 'dentist2')
        self.assertEqual(self.rooms.messages('dentist2', 'a', self.room), [])

    def test_mfa_rechecked_on_reads_and_sends(self):
        with self.assertRaises(AccessDenied):
            self.rooms.messages('low_mfa', 'a', self.room)
        with self.assertRaises(AccessDenied):
            self.rooms.send('low_mfa', 'a', self.room, 'Não autorizado', 'm-1')

    def test_membership_revocation_takes_effect_without_relogin(self):
        self.rooms.messages('dentist', 'a', self.room)
        with self.store.db:
            self.store.db.execute("UPDATE portal_memberships SET active=0 WHERE user_id='dentist'")
        with self.assertRaises(AccessDenied):
            self.rooms.messages('dentist', 'a', self.room)

    def test_assignment_removal_takes_effect(self):
        with self.store.db:
            self.store.db.execute("DELETE FROM portal_assignments WHERE user_id='dentist'")
        with self.assertRaises(AccessDenied):
            self.rooms.send('dentist', 'a', self.room, 'Mensagem', 'm-1')

    def test_subject_deactivation_denies_both_sides(self):
        with self.store.db:
            self.store.db.execute("UPDATE portal_subjects SET active=0 WHERE id='s-alice'")
        for token in ('alice', 'dentist'):
            with self.subTest(token=token), self.assertRaises(AccessDenied):
                self.rooms.messages(token, 'a', self.room)

    def test_participant_revocation_denies_replay_and_read(self):
        self.rooms.send('alice', 'a', self.room, 'Mensagem', 'm-1')
        self.rooms.revoke_participant('dentist', 'a', self.room, 'alice')
        with self.assertRaises(AccessDenied):
            self.rooms.send('alice', 'a', self.room, 'Mensagem', 'm-1')
        with self.assertRaises(AccessDenied):
            self.rooms.messages('alice', 'a', self.room)

    def test_revoked_professional_cannot_be_accidentally_readded(self):
        self.rooms.add_professional('dentist', 'a', self.room, 'dentist2')
        self.rooms.revoke_participant('dentist', 'a', self.room, 'dentist2')
        with self.assertRaises(AccessDenied):
            self.rooms.add_professional('dentist', 'a', self.room, 'dentist2')

    def test_expired_participant_denied(self):
        with self.store.db:
            self.store.db.execute('''UPDATE consultation_members SET expires_at=? WHERE user_id=?''',
                                  (self.now(), 'alice'))
        with self.assertRaises(AccessDenied):
            self.rooms.messages('alice', 'a', self.room)

    def test_invalid_expired_and_revoked_identity_denied(self):
        self.verifier.revoked.add('alice')
        for token in ('invalid', 'expired', 'alice'):
            with self.subTest(token=token), self.assertRaises(AccessDenied):
                self.rooms.messages(token, 'a', self.room)

    def test_only_host_closes_and_closed_room_rejects_actions(self):
        ref = self.release_attach()
        self.enable_video()
        with self.assertRaises(AccessDenied):
            self.rooms.close('alice', 'a', self.room)
        self.rooms.close('dentist', 'a', self.room)
        for operation in (
            lambda: self.rooms.send('alice', 'a', self.room, 'Mensagem', 'm-1'),
            lambda: self.rooms.messages('alice', 'a', self.room),
            lambda: self.rooms.open_document('alice', 'a', self.room, ref),
            lambda: self.rooms.join_video('alice', 'a', self.room),
        ):
            with self.assertRaises(AccessDenied):
                operation()
        self.assertEqual(self.video.calls, [])

    def test_expired_room_denied(self):
        self.clock[0] += 7200
        with self.assertRaises(AccessDenied):
            self.rooms.messages('alice', 'a', self.room)

    def test_messages_encrypted_and_bound_to_metadata(self):
        text = 'Dado sensível fictício não vai ao log'
        result = self.rooms.send('alice', 'a', self.room, text, 'm-1')
        cipher = self.store.db.execute('SELECT ciphertext FROM consultation_messages').fetchone()[0]
        self.assertNotIn(text.encode(), cipher)
        with self.store.db:
            self.store.db.execute('UPDATE consultation_messages SET sender_user=? WHERE id=?',
                                  ('dentist', result['id']))
        with self.assertRaises(InvalidTag):
            self.rooms.messages('alice', 'a', self.room)

    def test_idempotency_same_sender_creates_one_message_and_one_outbox_event(self):
        first = self.rooms.send('alice', 'a', self.room, 'Mensagem', 'm-1')
        second = self.rooms.send('alice', 'a', self.room, 'Mensagem', 'm-1')
        self.assertEqual(first, second)
        self.assertEqual(self.store.db.execute('SELECT count(*) FROM consultation_outbox').fetchone()[0], 1)
        with self.assertRaises(ValueError):
            self.rooms.send('alice', 'a', self.room, 'Alteração', 'm-1')

    def test_concurrent_duplicate_send_deduplicates(self):
        def send(_):
            return self.rooms.send('alice', 'a', self.room, 'Mensagem', 'same-request')['id']
        with ThreadPoolExecutor(max_workers=4) as pool:
            ids = list(pool.map(send, range(8)))
        self.assertEqual(len(set(ids)), 1)
        self.assertEqual(len(self.rooms.messages('alice', 'a', self.room)), 1)

    def test_outbox_failure_rolls_back_message(self):
        self.store.db.execute('''CREATE TRIGGER fail_test_outbox BEFORE INSERT ON consultation_outbox
            BEGIN SELECT RAISE(ABORT,'fixture failure'); END;''')
        with self.assertRaises(sqlite3.IntegrityError):
            self.rooms.send('alice', 'a', self.room, 'Mensagem', 'm-1')
        self.assertEqual(self.rooms.messages('alice', 'a', self.room), [])

    def test_idempotency_key_scoped_to_sender(self):
        one = self.rooms.send('alice', 'a', self.room, 'Primeira', 'm-1')
        two = self.rooms.send('dentist', 'a', self.room, 'Resposta', 'm-1')
        self.assertNotEqual(one['id'], two['id'])

    def test_rate_limit_and_retry_window(self):
        for n in range(30):
            self.rooms.send('alice', 'a', self.room, 'Mensagem', f'm-{n}')
        self.rooms.send('alice', 'a', self.room, 'Mensagem', 'm-0')
        with self.assertRaises(RateLimited):
            self.rooms.send('alice', 'a', self.room, 'Mensagem', 'm-30')
        self.clock[0] += 60
        self.rooms.send('alice', 'a', self.room, 'Mensagem', 'm-30')

    def test_text_limits_control_characters_and_safe_html_rendering(self):
        for text in (' ', 'x' * 2001, 'hello\x00'):
            with self.subTest(text=text[:20]), self.assertRaises(ValueError):
                self.rooms.send('alice', 'a', self.room, text, 'm-1')
        text = '<img src=x onerror="alert(1)">'
        self.assertNotIn('<', render_message_text(text))
        result = self.rooms.send('alice', 'a', self.room, text, 'm-2')
        self.assertEqual(result['text'], text)  # Plain text; never executable HTML.

    def test_pagination_cursor_cannot_cross_rooms(self):
        one = self.rooms.send('alice', 'a', self.room, 'Primeira', 'm-1')
        two = self.rooms.send('alice', 'a', self.room, 'Segunda', 'm-2')
        self.assertEqual(self.rooms.messages('alice', 'a', self.room, after_id=one['id']), [two])
        other = self.rooms.create('dentist', 'a', 's-bob', 'clinical')
        with self.assertRaises(AccessDenied):
            self.rooms.messages('bob', 'a', other, after_id=one['id'])

    def test_document_requires_release_and_patient_can_share_released_record(self):
        with self.assertRaises(AccessDenied):
            self.rooms.attach_record('dentist', 'a', self.room, self.record)
        self.portal.release_record('dentist', 'a', self.record)
        ref = self.rooms.attach_record('alice', 'a', self.room, self.record)
        self.assertEqual(self.rooms.open_document('dentist', 'a', self.room, ref),
                          {'note': 'Exame fictício privado'})

    def test_document_other_patient_and_wrong_category_denied(self):
        record = self.portal.create_record('dentist', 'a', 's-bob', 'clinical', {'note': 'Outro paciente'})
        self.portal.release_record('dentist', 'a', record)
        legal = self.portal.create_record('lawyer', 'a', 's-alice', 'legal', {'note': 'Caso jurídico'})
        self.portal.release_record('lawyer', 'a', legal)
        for record_id in (record, legal):
            with self.subTest(record=record_id), self.assertRaises(AccessDenied):
                self.rooms.attach_record('alice', 'a', self.room, record_id)

    def test_document_release_revocation_checked_on_each_open(self):
        ref = self.release_attach()
        self.rooms.open_document('alice', 'a', self.room, ref)
        with self.store.db:
            self.store.db.execute('UPDATE portal_records SET released=0 WHERE id=?', (self.record,))
        for token in ('alice', 'dentist'):
            with self.subTest(token=token), self.assertRaises(AccessDenied):
                self.rooms.open_document(token, 'a', self.room, ref)

    def test_document_room_grant_revocation_and_cross_room_denied(self):
        ref = self.release_attach()
        other = self.rooms.create('dentist', 'a', 's-alice', 'clinical')
        with self.assertRaises(AccessDenied):
            self.rooms.open_document('alice', 'a', other, ref)
        self.rooms.revoke_document('dentist', 'a', self.room, ref)
        with self.assertRaises(AccessDenied):
            self.rooms.open_document('alice', 'a', self.room, ref)
        with self.assertRaises(AccessDenied):
            self.rooms.attach_record('dentist', 'a', self.room, self.record)

    def test_legal_room_available_to_lawyer_and_client_only(self):
        room = self.rooms.create('lawyer', 'a', 's-alice', 'legal')
        self.rooms.send('alice', 'a', room, 'Dúvida jurídica fictícia', 'm-1')
        self.assertEqual(len(self.rooms.messages('lawyer', 'a', room)), 1)
        with self.assertRaises(AccessDenied):
            self.rooms.add_professional('lawyer', 'a', room, 'dentist')

    def test_video_disabled_by_default(self):
        with self.assertRaises(VideoDisabled):
            self.rooms.join_video('alice', 'a', self.room)

    def test_video_binding_server_scoped_token_short_lived_and_no_clinical_details(self):
        self.enable_video()
        grant = self.rooms.join_video('alice', 'a', self.room)
        request = self.video.calls[0]
        self.assertEqual(grant.external_room_id, 'server-controlled-room')
        self.assertEqual(grant.expires_at, self.now() + 120)
        self.assertNotEqual(request.participant_id, 'alice')
        self.assertEqual(request.role, 'participant')
        self.assertEqual(set(request.__dict__), {'external_room_id', 'participant_id', 'role', 'expires_at'})
        self.assertEqual(self.rooms.join_video('dentist', 'a', self.room).expires_at, self.now() + 120)
        self.assertEqual(self.video.calls[-1].role, 'host')

    def test_video_rejects_wrong_provider_or_missing_binding(self):
        self.enable_video()
        for binding in (None, VideoBinding('other', 'room')):
            self.rooms.binding_resolver = lambda tenant, room: binding
            with self.assertRaises(VideoDisabled):
                self.rooms.join_video('alice', 'a', self.room)
        self.assertEqual(self.video.calls, [])

    def test_video_rechecks_session_after_provider_issue(self):
        self.enable_video()
        self.video.after_issue = lambda: self.verifier.revoked.add('alice')
        with self.assertRaises(AccessDenied):
            self.rooms.join_video('alice', 'a', self.room)
        self.assertEqual(len(self.video.revoked), 1)

    def test_video_rechecks_reduced_participant_and_room_validity(self):
        self.enable_video()
        for table in ('consultation_members', 'consultation_rooms'):
            with self.subTest(table=table):
                self.video.after_issue = lambda: self.store.db.execute(
                    f'UPDATE {table} SET expires_at=?', (self.now() + 10,))
                with self.assertRaises(ValueError):
                    self.rooms.join_video('alice', 'a', self.room)
        self.assertEqual(len(self.video.revoked), 2)

    def test_participant_revocation_revokes_issued_grant_and_ejects_active_call(self):
        self.enable_video()
        grant = self.rooms.join_video('alice', 'a', self.room)
        self.rooms.revoke_participant('dentist', 'a', self.room, 'alice')
        self.assertEqual(self.video.revoked, [grant])
        self.assertEqual(self.video.ejected, [(grant.external_room_id, grant.participant_id)])
        self.assertEqual(self.store.db.execute('SELECT state FROM consultation_video_cleanup').fetchone()[0], 'done')

    def test_room_close_revokes_all_grants_and_ends_external_room(self):
        self.enable_video()
        self.rooms.join_video('alice', 'a', self.room)
        self.rooms.join_video('dentist', 'a', self.room)
        self.rooms.close('dentist', 'a', self.room)
        self.assertEqual(len(self.video.revoked), 2)
        self.assertEqual(self.video.closed, ['server-controlled-room'])

    def test_video_cleanup_failure_keeps_local_revocation_and_pending_retry(self):
        self.enable_video()
        grant = self.rooms.join_video('alice', 'a', self.room)
        original = self.video.eject

        def outage(*args):
            raise TimeoutError('Provider error with potentially sensitive details')

        self.video.eject = outage
        with self.assertRaises(VideoRevocationPending):
            self.rooms.revoke_participant('dentist', 'a', self.room, 'alice')
        with self.assertRaises(AccessDenied):
            self.rooms.messages('alice', 'a', self.room)
        row = self.store.db.execute('SELECT * FROM consultation_video_cleanup').fetchone()
        self.assertEqual(row['state'], 'pending')
        self.video.eject = original
        self.rooms._attempt_video_cleanup(row['id'])
        self.assertEqual(self.video.ejected, [(grant.external_room_id, grant.participant_id)])
        self.assertEqual(self.store.db.execute('SELECT state FROM consultation_video_cleanup').fetchone()[0], 'done')

    def test_expired_join_grant_still_ejects_established_participant(self):
        self.enable_video()
        grant = self.rooms.join_video('alice', 'a', self.room)
        self.clock[0] += 121
        self.rooms.revoke_participant('dentist', 'a', self.room, 'alice')
        self.assertEqual(self.video.ejected, [(grant.external_room_id, grant.participant_id)])

    def test_video_grants_stored_encrypted_and_incomplete_adapter_disabled(self):
        self.enable_video()
        grant = self.rooms.join_video('alice', 'a', self.room)
        ciphertext = self.store.db.execute('SELECT ciphertext FROM consultation_video_grants').fetchone()[0]
        self.assertNotIn(grant.token.encode(), ciphertext)
        self.video.eject = None
        with self.assertRaises(VideoDisabled):
            self.rooms.join_video('alice', 'a', self.room)

    def test_video_mfa_and_membership_checks_prevent_token_issue(self):
        self.enable_video()
        self.rooms.revoke_participant('dentist', 'a', self.room, 'alice')
        for token in ('alice', 'low_mfa', 'reception', 'lawyer', 'bob'):
            with self.subTest(token=token), self.assertRaises(AccessDenied):
                self.rooms.join_video(token, 'a', self.room)
        self.assertEqual(self.video.calls, [])

    def test_video_rejects_wrong_scope_or_expiry_and_revokes_rejected_grant(self):
        self.enable_video()
        for changes in ({'external_room_id': 'another-room'}, {'participant_id': 'another-user'},
                        {'expires_at': self.now() + 121}, {'expires_at': float('nan')},
                        {'token': 'short'}):
            self.video.transform = lambda grant: replace(grant, **changes)
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                self.rooms.join_video('alice', 'a', self.room)
        self.assertEqual(len(self.video.revoked), 5)

    def test_audit_and_outbox_never_contain_message_document_or_video_token(self):
        self.enable_video()
        text = 'Sintoma fictício que não deve aparecer no log'
        self.rooms.send('alice', 'a', self.room, text, 'm-1')
        ref = self.release_attach()
        self.rooms.open_document('alice', 'a', self.room, ref)
        self.rooms.join_video('alice', 'a', self.room)
        with self.assertRaises(AccessDenied):
            self.rooms.messages('bob', 'a', self.room)
        log = json.dumps([dict(row) for row in self.store.db.execute('SELECT * FROM portal_audit')],
                          ensure_ascii=False)
        log += json.dumps([dict(row) for row in self.store.db.execute('SELECT * FROM consultation_outbox')])
        for secret in (text, 'Exame fictício privado', 'opaque-fixture-token-only', 'server-controlled-room'):
            self.assertNotIn(secret, log)
        self.assertIn('denied', log)


if __name__ == '__main__':
    unittest.main()
