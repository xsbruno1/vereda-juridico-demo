import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
import {SERVICES,TABS,serviceKey,freshVisit,setRole,setTab,templates,addMessage,visibleDocuments,simulateAttachment,releaseDocument,removeShare,closeVisit,transcript,documentBody} from '../../public/vereda/atendimento/core.js';

test('only explicitly supported professional sectors can be selected',()=>{
 assert.deepEqual(Object.keys(SERVICES),['medicina','odontologia','psicologia','psiquiatria','advocacia']);
 for(const invalid of ['estetica','petshop','hotelaria','__proto__',null])assert.equal(serviceKey(invalid),'medicina');
 assert.equal(serviceKey('psicologia'),'psicologia');
});
test('invalid roles and tabs do not mutate the demonstration',()=>{
 const state=freshVisit('medicina');
 assert.throws(()=>setRole(state,'admin'));assert.equal(state.role,'client');
 assert.throws(()=>setTab(state,'secret'));assert.equal(state.tab,'chat');
 for(const tab of TABS)assert.equal(setTab(state,tab).tab,tab);
});
test('client only sees released records and never private notes or drafts',()=>{
 const state=freshVisit('medicina');
 assert.deepEqual(visibleDocuments(state).map(doc=>doc.id),['summary']);
 assert.throws(()=>documentBody(state,'plan'));assert.throws(()=>documentBody(state,'internal'));
 assert.throws(()=>releaseDocument(state,'plan'));
 setRole(state,'professional');assert.deepEqual(visibleDocuments(state).map(doc=>doc.id),['summary','plan']);
 assert.throws(()=>releaseDocument(state,'internal'));
});
test('release is scoped to the current appointment and revocation hides shared record',()=>{
 const state=freshVisit('odontologia');setRole(state,'professional');
 state.documents.push({id:'foreign',title:'Other appointment',origin:'professional',status:'draft',private:false,shared:true,visitId:'another-visit'});
 assert.throws(()=>releaseDocument(state,'foreign'));
 releaseDocument(state,'plan');setRole(state,'client');
 assert.equal(visibleDocuments(state).some(doc=>doc.id==='plan'),true);
 assert.equal(visibleDocuments(state).some(doc=>doc.id==='foreign'),false);
 assert.throws(()=>removeShare(state,'plan'));
 setRole(state,'professional');removeShare(state,'plan');setRole(state,'client');
 assert.equal(visibleDocuments(state).some(doc=>doc.id==='plan'),false);
});
test('fictional attachment requires client, cannot be duplicated and is withdrawable',()=>{
 const state=freshVisit('medicina');setRole(state,'professional');
 assert.throws(()=>simulateAttachment(state));setRole(state,'client');simulateAttachment(state);
 assert.throws(()=>simulateAttachment(state));
 setRole(state,'professional');assert.equal(visibleDocuments(state).some(doc=>doc.id==='uploaded'),true);
 setRole(state,'client');removeShare(state,'uploaded');
 assert.equal(visibleDocuments(state).some(doc=>doc.id==='uploaded'),true);
 setRole(state,'professional');assert.equal(visibleDocuments(state).some(doc=>doc.id==='uploaded'),false);
 assert.throws(()=>releaseDocument(state,'uploaded'));
});
test('canned conversation never invents a professional response or accepts custom private text',()=>{
 const state=freshVisit('advocacia');
 assert.throws(()=>addMessage(state,'my confidential case'));
 assert.throws(()=>addMessage(state,'review'));
 addMessage(state,'question');assert.equal(state.messages.length,1);
 assert.equal(state.messages[0].role,'client');assert.equal(state.messages[0].status,'local');
 assert.match(state.messages[0].text,/caso/);assert.throws(()=>addMessage(state,'question'));
 setRole(state,'professional');addMessage(state,'review');assert.equal(state.messages.length,2);
 assert.equal(state.messages[1].role,'professional');
 state.messages.push({id:55,visitId:'foreign',text:'not this visit'});
 assert.equal(transcript(state).length,2);
 const copy=transcript(state);copy[0].text='changed';assert.notEqual(state.messages[0].text,'changed');
});
test('closing the example blocks new conversations, files and releases',()=>{
 const state=freshVisit('psiquiatria');simulateAttachment(state);setRole(state,'professional');closeVisit(state);
 assert.throws(()=>addMessage(state,'review'));assert.throws(()=>releaseDocument(state,'plan'));assert.throws(()=>removeShare(state,'summary'));
 setRole(state,'client');assert.throws(()=>simulateAttachment(state));
 assert.ok(documentBody(state,'summary'));assert.equal(setTab(state,'history').tab,'history');
});
test('sectors have isolated state and appropriate vocabulary',()=>{
 const legal=freshVisit('advocacia');const psychology=freshVisit('psicologia');
 addMessage(legal,'question');simulateAttachment(legal);
 assert.equal(psychology.messages.length,0);assert.equal(psychology.documents.length,3);
 assert.match(SERVICES.advocacia.history,/caso/);assert.doesNotMatch(SERVICES.advocacia.history,/prontuário|clínico/i);
 assert.doesNotMatch(SERVICES.psicologia.next.join(' '),/medica|receita|prescri/i);
 assert.doesNotMatch(templates(psychology).map(item=>item.text).join(' '),/medica|receita|prescri/i);
});
test('page mounts one persistent stage, updates only the right-hand panel, and uses inline document preview',()=>{
 const base=new URL('../../public/vereda/atendimento/',import.meta.url);
 const html=readFileSync(new URL('index.html',base),'utf8');const app=readFileSync(new URL('app.js',base),'utf8');
 assert.equal((html.match(/id="video-stage"/g)||[]).length,1);
 assert.match(html,/data-persistent-stage/);assert.match(app,/panel\.innerHTML=/);
 assert.doesNotMatch(app,/(?:video-stage|video-scene)[^\n]{0,100}(?:innerHTML|outerHTML|replaceChildren)/);
 assert.doesNotMatch(html,/<iframe|<dialog/i);assert.doesNotMatch(app,/showModal|window\.open|fetch\(|localStorage|sessionStorage|getUserMedia|RTCPeerConnection|WebSocket/);
 assert.match(app,/class="inline-document"/);assert.match(app,/query\.get\('visao'\)==='equipe'/);
 assert.match(html,/Demonstração visual · chamada não conectada/);
 assert.match(html,/type="module"/);
});
test('Meet uses the existing strict URL validator and never opens a supplied URL automatically',()=>{
 const source=readFileSync(new URL('../../public/vereda/assets/room-core.js',import.meta.url),'utf8');
 const scope={URL};vm.runInNewContext(source,scope);
 assert.equal(scope.VeredaRoom.meetingURL('https://meet.google.com/abc-defg-hij'),'https://meet.google.com/abc-defg-hij');
 for(const invalid of ['javascript:alert(1)','https://meet.google.com.evil.test/abc-defg-hij','https://evil.test/','https://meet.google.com/abc-defg-hij?x=1','https://user@meet.google.com/abc-defg-hij','http://meet.google.com/abc-defg-hij'])assert.equal(scope.VeredaRoom.meetingURL(invalid),null);
 const app=readFileSync(new URL('../../public/vereda/atendimento/app.js',import.meta.url),'utf8');
 assert.match(app,/globalThis\.VeredaRoom\?\.meetingURL/);
 assert.match(app,/addEventListener\('input',clearMeet\)/);
 assert.doesNotMatch(app,/location\.(?:href|assign|replace)\s*[=(]/);
});
